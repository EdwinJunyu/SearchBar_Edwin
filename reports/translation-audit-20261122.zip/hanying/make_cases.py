from pathlib import Path
from html.parser import HTMLParser
from html import unescape
import hashlib, json, sqlite3, re
here=Path(__file__).resolve().parent
db=sqlite3.connect((here.parent/'catalog.db').as_uri()+'?mode=ro&immutable=1',uri=True)
cache={}
class Ref(HTMLParser):
    def __init__(self):
        super().__init__();self.link='';self.buff=[];self.active=False
    def handle_starttag(self,tag,attrs):
        if tag=='a' and dict(attrs).get('href','').startswith('entry://'):
            self.link=dict(attrs)['href'];self.active=True
    def handle_endtag(self,tag):
        if tag=='a':self.active=False
    def handle_data(self,text):
        if self.active:self.buff.append(text)

out=[]
for line in (here.parent/'primary/sample.jsonl').read_text('utf-8').splitlines():
    h=json.loads(line)
    if h['book']!='hanying':continue
    raw,=db.execute("select raw from entries where dict='hanying' and ordinal=?",(h['ordinal'],)).fetchone()
    ref=Ref();ref.feed(raw)
    target,anchor=(ref.link[8:].split('#',1)+[''])[:2]
    if not re.fullmatch(r'subEntry\d+',anchor):continue
    label=''.join(ref.buff).strip();prefix=target+':'
    if not label.startswith(prefix) or label[len(prefix):].strip()!=h['query']:continue
    # Require a lexical Chinese expression (excluding dictionary explanations beginning with parentheses).
    match=re.fullmatch(r'([\u3400-\u9fff][\u3400-\u9fff（）()\[\]、·-]*)(?:\s+|(?=\{))(.+)',h['query'])
    if not match or not re.search('[A-Za-z]',match[2]):continue
    if target not in cache:
        cache[target]=db.execute("select ordinal,raw from entries where dict='hanying' and ordinal in (select ordinal from terms where dict='hanying' and kind=0 and term=?)",(target,)).fetchall()
    parents=[]
    for oid,body in cache[target]:
        found=re.search(r'<a name="'+re.escape(anchor)+r'"\s*/>(.+?)</span>',body,re.I|re.S)
        if found and unescape(re.sub(r'<[^>]*>','',found[1])).strip()==h['query']:parents.append(oid)
    if not parents:raise AssertionError((h['query'],target,anchor))
    out.append(dict(partition=h['partition'],suite='hanying_subentry',query=match[1],expected=dict(id=h['ordinal'],head=match[1],gloss=match[2].strip(),target=target+'#'+anchor),parentOrdinals=parents,legacyKey=h['query']))
(here/'cases.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in out),'utf-8')
for part in ['audit','holdout']:print(part,sum(r['partition']==part for r in out))
