param([string]$Bin,[ValidateSet('baseline','final','holdout','holdout-baseline')][string]$Round)
$ErrorActionPreference='Stop'
$Bin=(Resolve-Path $Bin).Path
foreach($lib in 'SQLitePCLRaw.core','SQLitePCLRaw.provider.winsqlite3','Microsoft.Data.Sqlite','E_Search'){
    $asm=[Reflection.Assembly]::LoadFrom((Join-Path $Bin "$lib.dll"))
}
[SQLitePCL.raw]::SetProvider([SQLitePCL.SQLite3Provider_winsqlite3]::new())
$path=(Resolve-Path (Join-Path $PSScriptRoot '../catalog.db')).Path
$db=$asm.GetType('DictionaryStore').GetConstructor([type[]]@([string],[bool])).Invoke([object[]]@([string]$path,$true))
$file=[IO.StreamWriter]::new((Join-Path $PSScriptRoot "$Round.jsonl"),$false,[Text.UTF8Encoding]::new($false))
$token=[Threading.CancellationToken]::None
$ok=0;$count=0
try {
    foreach($line in [IO.File]::ReadLines((Join-Path $PSScriptRoot 'cases.jsonl'))) {
        $c=ConvertFrom-Json -AsHashtable $line
        if (($c.partition -eq 'holdout') -ne ($Round -like 'holdout*')) {continue}
        $watch=[Diagnostics.Stopwatch]::StartNew()
        $actual=$null
        try {
            foreach ($h in $db.Search($c.query,'hanying',$token)) {
                if($h.Entry.EntryId -ne $c.expected.id) {continue}
                $raw=$db.CurrentBody($h.Entry)
                $target=[Net.WebUtility]::HtmlDecode([regex]::Match($raw,'href="entry://([^"]+)"').Groups[1].Value)
                $actual=[ordered]@{id=$h.Entry.EntryId;head=$h.Entry.Headword;gloss=$h.Entry.Gloss;target=$target}
                break
            }
        } catch {$actual=@{error=$_.Exception.Message}}
        $elapsed=[Math]::Round($watch.Elapsed.TotalMilliseconds,4)
        $pass=($c.expected|ConvertTo-Json -Compress) -ceq ($actual|ConvertTo-Json -Compress)
        $row=[ordered]@{suite=$c.suite;query=$c.query;expected=$c.expected;actual=$actual;pass=$pass;ms=$elapsed}
        $file.WriteLine(($row|ConvertTo-Json -Depth 5 -Compress));$count++;if ($pass) {$ok++}
    }
} finally {$file.Dispose();$db.Dispose()}
Write-Output "$Round $ok / $count"
