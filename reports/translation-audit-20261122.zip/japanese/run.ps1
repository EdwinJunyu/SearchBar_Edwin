param([ValidateSet('baseline','final')][string]$Stage, [string]$AssemblyDirectory, [switch]$Analytic, [string]$OutputPath)
$ErrorActionPreference='Stop'
if (!$AssemblyDirectory) { $AssemblyDirectory=if($Stage -eq 'baseline') { Join-Path $PSScriptRoot 'baseline-bin' } else { Join-Path $PSScriptRoot '../../../bin/Release/net10.0' } }
foreach ($lib in 'SQLitePCLRaw.core','SQLitePCLRaw.provider.winsqlite3','Microsoft.Data.Sqlite','E_Search') {
    $assembly=[Reflection.Assembly]::LoadFrom((Resolve-Path (Join-Path $AssemblyDirectory "$lib.dll")).Path)
}
[SQLitePCL.raw]::SetProvider([SQLitePCL.SQLite3Provider_winsqlite3]::new())
$ctor=$assembly.GetType('DictionaryStore').GetConstructor([type[]]@([string],[bool]))
$dbfile=(Resolve-Path (Join-Path $PSScriptRoot '../catalog.db')).Path.Replace('\','/')
$store=$ctor.Invoke([object[]]@("file:$dbfile`?immutable=1",$true))
$manifest = if ($Analytic) { 'cases-analytic.json' } else { 'cases.json' }
$cases=Get-Content -Raw -Encoding utf8 (Join-Path $PSScriptRoot $manifest) | ConvertFrom-Json
$all=[System.Management.Automation.Language.NullString]::Value
$token=[Threading.CancellationToken]::None
$out=Join-Path $PSScriptRoot $(if ($Analytic) { "$Stage-analytic.jsonl" } else { "$Stage.jsonl" })
if ($OutputPath) { $out=$OutputPath }
if ($Stage -eq 'baseline' -and (Test-Path -LiteralPath $out)) { throw 'Baseline already exists.' }
$writer=[IO.StreamWriter]::new($out,$false,[Text.UTF8Encoding]::new($false))
try {
    foreach ($c in $cases) {
        $sw=[Diagnostics.Stopwatch]::StartNew()
        $rows=$store.Search([string]$c.query,$all,$token)
        $sw.Stop()
        $actual=@(foreach ($r in $rows) { [ordered]@{headword=$r.Entry.Headword;term=$r.Term;method=$r.Method;book=$r.Entry.DictionaryId} })
        $head=$c.expected.headword
        $distinct=@($rows | ForEach-Object { $_.Entry.Headword } | Select-Object -Unique)
        $rank=[Array]::IndexOf($distinct,$head)+1
        $ok=$rank -in 1..3
        if ($c.expected.surface) { $ok=$ok -and @($rows | Where-Object {$_.Term -ceq $c.expected.surface -and $_.Entry.Headword -ceq $head -and $_.Method -eq 'phrase'}).Count -gt 0 }
        if ($c.suite -eq 'negative') { $ok=@($rows | Where-Object {$_.Entry.Headword -ceq $head -and ($_.Method -ne 'phrase' -or $_.Term -ceq $c.query)}).Count -eq 0 }
        $record=[ordered]@{suite=$c.suite;query=$c.query;expected=$c.expected;actual=$actual;pass=[bool]$ok;ms=[math]::Round($sw.Elapsed.TotalMilliseconds,3);rank=$rank;evidence=$c.evidence}
        $writer.WriteLine(($record | ConvertTo-Json -Depth 6 -Compress))
    }
} finally { $writer.Dispose();$store.Dispose() }
