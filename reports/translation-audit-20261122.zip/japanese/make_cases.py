"""Freeze deterministic Japanese audit cases from catalog.db; invoke run.ps1 separately for each build."""
import ctypes as C
import html
import json
import random
import re
import sqlite3
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SEED = 20261122
rng = random.Random(SEED)
db = sqlite3.connect((ROOT.parent / "catalog.db").as_uri() + "?immutable=1", uri=True)

# Independent forward inflection. POS comes from the Sanseido dictionary's printed labels.
ENDS = {"う":("い","わ","え","って"), "く":("き","か","け","いて"),
        "ぐ":("ぎ","が","げ","いで"), "す":("し","さ","せ","して"),
        "つ":("ち","た","て","って"), "ぬ":("に","な","ね","んで"),
        "ぶ":("び","ば","べ","んで"), "む":("み","ま","め","んで"), "る":("り","ら","れ","って")}
ROW = dict(zip("ワカガサタナバマラ", ENDS))
pos_re = re.compile(r"[（(](動(?:[ワカガサタナバマラ]五|[ァ-ヶ][上下]一|サ変))(?:\[[^\]]+\])?[)）]")
verbs = {}
for h, r, ordinal, raw in db.execute("select head,reading,ordinal,substr(raw,1,520) from entries where dict='sanseido' and reading is not null and link is null order by ordinal"):
    if h in verbs or not re.search(r"[一-鿿]", h) or not re.fullmatch(r"[一-鿿々ぁ-ゖァ-ヺー]{2,12}", h):
        continue
    if not re.fullmatch(r"[ぁ-ゖー]{2,14}", r) or "【" + h + "】" not in raw:
        continue
    m = pos_re.search(html.unescape(re.sub("<[^>]+>", "", raw)))
    if not m:
        continue
    pos = m[1]
    if pos.endswith("五") and h[-1] == ROW[pos[1]] and r.endswith(h[-1]):
        cls = "godan"
    elif pos.endswith("一") and h.endswith("る") and r.endswith("る"):
        cls = "ichidan"
    elif pos == "動サ変" and h.endswith("する") and r.endswith("する"):
        cls = "suru"
    else:
        continue
    # Honorific -aru verbs and lexical -u exceptions require a distinct forward paradigm.
    if h in ("なさる","下さる","仰る","いらっしゃる","御座る","問う","乞う","請う","厭う"):
        continue
    verbs[h] = (r, cls, pos, ordinal)

def forms(head, cls):
    if cls == "godan":
        stem = head[:-1]
        i, a, e, te = ENDS[head[-1]]
        teform = stem + ("って" if head.endswith("行く") else te)
        return stem+i, teform, stem+a+"れる", stem+e+"る", stem+a+"せる"
    if cls == "suru":
        stem = head[:-2]
        return stem+"し", stem+"して", stem+"される", stem+"できる", stem+"させる"
    stem = head[:-1]
    return stem, stem+"て", stem+"られる", stem+"られる", stem+"させる"

cases = []
used = set()
def add(suite, query, head, evidence, surface=None):
    assert (suite,query) not in {(c["suite"],c["query"]) for c in cases}
    cases.append(dict(suite=suite, query=query, expected=dict(headword=head, surface=surface),
                      evidence=evidence))

for suite in ["polite","progressive","passive","potential","multistep","sentence","kana"]:
    for cls, count in (("godan",24),("ichidan",16),("suru",8)):
        pool = sorted(h for h, v in verbs.items() if v[1] == cls and h not in used)
        for head in rng.sample(pool, count):
            used.add(head)
            r, _, pos, ordinal = verbs[head]
            i, te, passive, potential, causative = forms(head, cls)
            queries = {"polite":i+"ませんでした","progressive":te+"います","passive":passive[:-1]+"ました",
                       "potential":potential[:-1]+"ません","multistep":causative[:-1]+"られていませんでした",
                       "sentence":te+"いませんでした","kana":r}
            q = queries[suite]
            surface = q if suite == "sentence" else None
            if surface:
                q = "昨日、" + q + "。"
            add(suite,q,head,dict(book="sanseido",ordinal=ordinal,reading=r,pos=pos),surface)

# Windows ICU's published transliteration rules are independent of the application's romaji decoder.
icu = C.CDLL("icu.dll")
icu.utrans_openU.argtypes = [C.c_wchar_p,C.c_int32,C.c_int,C.c_wchar_p,C.c_int32,C.c_void_p,C.POINTER(C.c_int32)]
icu.utrans_openU.restype = C.c_void_p
icu.utrans_transUChars.argtypes = [C.c_void_p,C.c_wchar_p,C.POINTER(C.c_int32),C.c_int32,C.c_int32,C.POINTER(C.c_int32),C.POINTER(C.c_int32)]
err = C.c_int32(0)
handle = icu.utrans_openU("Katakana-Latin",-1,0,None,0,None,C.byref(err))
def romanize(kana):
    katakana = "".join(chr(ord(c)+96) if "ぁ" <= c <= "ゖ" else c for c in kana)
    buf = C.create_unicode_buffer(katakana, 150)
    length, end = C.c_int32(len(katakana)), C.c_int32(len(katakana))
    icu.utrans_transUChars(handle,buf,C.byref(length),150,0,C.byref(end),C.byref(err))
    if err.value > 0:
        raise RuntimeError(err.value)
    return buf.value

for special in (False, True):
    if not special:
        pool = [(h,r,n,"sanseido") for h,(r,cls,pos,n) in sorted(verbs.items()) if h not in used]
    else:
        pool = list(db.execute("select e.head,e.reading,e.ordinal,'shogakukan' from entries e where dict='shogakukan' and head=reading and reading like '%ー%' and length(reading) between 3 and 10 and link is null order by ordinal"))
    rng.shuffle(pool)
    count, seen = 0,set()
    for h,r,n,book in pool:
        if h in used or (special and not re.fullmatch(r"[ァ-ヶー]+",r)): continue
        latin=romanize(r)
        # ICU uses auxiliary ~ spellings for small kana in some uncommon sequences, outside standard Hepburn.
        if not re.fullmatch(r"[a-zāīūēō']+",latin) or latin in seen: continue
        seen.add(latin); used.add(h)
        add("romaji-long" if special else "romaji",latin,h,dict(book=book,ordinal=n,reading=r,romanizer="Windows ICU Katakana-Latin"))
        count += 1
        if count == 30: break
    assert count == 30

# A malformed polite ending is not a whole-word inflection. Legitimate *shorter* marked phrase matches are allowed.
for head in rng.sample(sorted(set(verbs)-used),32):
    r,cls,pos,n=verbs[head]
    i,*_=forms(head,cls)
    q=i+"ましだ"
    assert not db.execute("select 1 from terms where term=? limit 1",(q,)).fetchone()
    add("negative",q,head,dict(book="sanseido",ordinal=n,reading=r,pos=pos,criterion="no full-span claim for the malformed ending"))
out=ROOT/"cases.json"
payload=json.dumps(cases,ensure_ascii=False,indent=1)+"\n"
if out.exists() and out.read_text(encoding="utf-8") != payload:
    raise RuntimeError("Frozen manifest differs; refusing to replace it")
if not out.exists(): out.write_text(payload,encoding="utf-8")
print(SEED,len(verbs),Counter(x["suite"] for x in cases))

# A supplementary, independently grammatical potential for every verb class, including
# lexical one-kanji suru verbs where direct X-dekiru is not reliably interchangeable.
eligible = [c for c in cases if c["suite"] == "potential"]
extra = [c for c in eligible if c["evidence"]["pos"] == "動サ変"]
extra += random.Random(SEED+1).sample([c for c in eligible if c["evidence"]["pos"] != "動サ変"],24)
analytic = [dict(suite="potential-analytic",query=c["expected"]["headword"]+"ことができません",
                 expected=c["expected"],evidence=c["evidence"]) for c in extra]
extra_path=ROOT/"cases-analytic.json"
data=json.dumps(analytic,ensure_ascii=False,indent=1)+"\n"
if extra_path.exists() and extra_path.read_text(encoding="utf-8") != data:
    raise RuntimeError("Frozen supplementary manifest differs")
if not extra_path.exists(): extra_path.write_text(data,encoding="utf-8")