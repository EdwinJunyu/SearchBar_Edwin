"""Validate paired frozen cases and summarize both groups without removing misses."""
import hashlib, json, math
from pathlib import Path
import sys
root = Path(__file__).resolve().parent
def load(name):
    return [json.loads(line) for line in (root/name).read_text(encoding="utf-8").splitlines()]
def digest(path):
    with path.open("rb") as src:
        return hashlib.file_digest(src,"sha256").hexdigest()
def rank(values, percentile):
    values = sorted(values)
    return values[math.ceil(len(values)*percentile)-1]
report = dict(seed=20261122, baseline_commit="43d8b02924e04759394dcebe7ccb42d295c24bb9",
              baseline_assembly_sha256=digest(root/"baseline-bin"/"E_Search.dll"),
              final_assembly_sha256=digest(root.parents[2]/"bin"/"Release"/"net10.0"/"E_Search.dll"),
              criteria="Positive: asserted canonical head among first three distinct displayed heads, preserving exact surface on sentence rows. Negative: no full-query claim for malformed polite form; shorter text explicitly returned as a phrase is allowed.",
              independent_oracle="Sanseido printed POS + forward conjugation; Windows ICU Katakana-Latin transliteration; no production deinflection or ranking code used to generate labels.",
              groups={}, residual=[])
for name,suffix in (("original",""),("supplement","-analytic")):
    a,b=(load(k+suffix+".jsonl") for k in ("baseline","final"))
    manifest=json.loads((root/("cases"+suffix+".json")).read_text(encoding="utf-8"))
    assert [(c["suite"],c["query"],c["expected"]) for c in manifest] == [(c["suite"],c["query"],c["expected"]) for c in a] == [(c["suite"],c["query"],c["expected"]) for c in b]
    details={}
    for suite in dict.fromkeys(c["suite"] for c in a):
        bef=[c for c in a if c["suite"]==suite]; aft=[c for c in b if c["suite"]==suite]
        details[suite]=dict(n=len(bef),baseline=sum(c["pass"] for c in bef),final=sum(c["pass"] for c in aft))
        if suite!="negative":
            details[suite]["final_first_head"]=sum(c["rank"]==1 for c in aft)
    report["groups"][name]=dict(n=len(a),baseline=sum(c["pass"] for c in a),final=sum(c["pass"] for c in b),
                               gained=sum(not x["pass"] and y["pass"] for x,y in zip(a,b)),
                               lost=sum(x["pass"] and not y["pass"] for x,y in zip(a,b)),suites=details,
                               search_ms={k:{"p50":rank([c["ms"] for c in v],.5),"p95":rank([c["ms"] for c in v],.95)} for k,v in (("baseline",a),("final",b))})
    for c in b:
        if c["pass"]: continue
        reason=("different homophone outside first three" if c["rank"] else
                "literal head 剥れる has another reading and blocks weak potential guess" if c["expected"]["headword"]=="剥る" else
                "oracle uncertainty: the automatic X-dekiru form is not necessarily idiomatic for a lexical suru verb")
        report["residual"].append(dict(suite=c["suite"],query=c["query"],expected=c["expected"],rank=c["rank"],reason=reason))
text=json.dumps(report,ensure_ascii=False,indent=2)+"\n"
(root/"summary.json").write_text(text,encoding="utf-8")
for k,g in report["groups"].items(): print(k,g["baseline"],g["final"],g["n"],g["gained"],g["lost"])
