# E_Search 翻译检索审计复验说明

**先看 `results.csv`。** 用 Excel 或其他支持 UTF-8 的表格软件打开，可按“组别”“分组”“修复后通过”筛选。每行列出输入、期望、修复前后实际输出、通过标志和耗时。“逐条记录”指向 ZIP 中的 JSONL 文件。JSONL 每一行都是一个独立的 JSON 对象，保留候选列表、来源和各专项实际检查的字段。`environment.json` 记录本次运行的环境和构建标识。

## 冻结版本与输入

| 对照物 | 本次审计记录 |
| --- | --- |
| 修复前 Git 提交 | `43d8b02924e04759394dcebe7ccb42d295c24bb9` |
| 快照 `catalog.db` | 867,033,088 字节，SHA-256 `BDB0C8B50C85E6441F96B76A7309FEA5520E7B4107BE04D36C3DDB79511D8E9E` |
| 修复前命令行程序集 | SHA-256 `24CCF92BD1D8D14CDBB36FE32C415F494FEEBF6266EFF7A9BB9F44B0E2EABA0A` |
| 修复前 WPF 程序集 | SHA-256 `7F2F41BAACC0B9AC6CAD87C02D020EF7C1EE8AE46B86182B6A7F4CF931BDAEB2` |
| 修复后命令行程序集 | SHA-256 `6455FF4B353C0B141CA7F52DBD1128E438900B029BAB7222D57DF681860D1255` |
| 修复后 WPF 程序集 | SHA-256 `C137399FFD391F5DB215EC79FDE856B7A42D16B2806FF4DCC893500BA4EFA313` |

主清单 `primary/sample.jsonl` 含四部词典的 7,000 个不同词头。词头经过 NFKC、去首尾空格和小写归一化，按种子 `E_Search:20261122:v1`、词典 ID 和规范词头共同生成的 SHA-256 排序。每本取 1,500 个主样本和 250 个保留样本，并记录原始词条哈希。独立专项有各自的筛选、抽样和判定条件，同一输入可以进入不同测试。英语专项的两个种子为 20261122 和 11222027，日语与结果呈现专项的主种子为 20261122。小学馆的首义和跨行续义分别使用 20261123 和 20261124。汉英专项用父词条里的编号小节逐条验证双语参见。各 `cases*` 文件保存本次实际输入。

## 一键复验

需要 Windows x64、含 .NET 10 Windows Desktop 的 SDK、PowerShell 7（`pwsh`）、Python 3.11 或以上（`python` 指向该解释器）和 Git。建议使用与 `environment.json` 相同的版本。WPF 检查使用可用的桌面会话，窗口离屏显示。首次构建需能还原项目现有 NuGet 包，并取得项目校验过的 Everything SDK；已有项目缓存可以复用。

1. 准备一个独立的 E_Search Git 工作树，检出本报告对应的修复版。保留原始 ZIP，把包中内容解压到该项目的 `.data/translation-audit-20261122/`，使 `replay.ps1` 和 `results.csv` 处于同一层。ZIP 内含审计脚本与证据，程序源代码使用项目仓库，词库使用本人的原始安装或备份。
2. 将上表对应的独立、一致的 `catalog.db` 放到解压目录，然后在项目根目录运行下列命令。也可直接用下一节的 `-SourceDatabase` 从自有词库生成快照。
3. 脚本会创建一个全新的临时项目，把清单、探针、数据库和两套目标程序集复制到那里。运行结束会打印逐条结果目录。原始 ZIP 和解压目录已有的 JSONL 可继续用作对照。

```powershell
pwsh -NoProfile -File .data/translation-audit-20261122/replay.ps1
```

脚本默认用 `git archive` 将冻结提交导出至临时源码目录并执行 Release 构建；随后构建指定项目当前工作树。两次构建各用自己的 `bin/Release` 和 `obj`。如果已有验证过的两套构建，传入各自含 `net10.0`、`net10.0-windows` 两个子目录的 Release 路径。例如，在 PowerShell 里运行下面的命令，并将尖括号中的值换为实际路径。

```powershell
& ./.data/translation-audit-20261122/replay.ps1 `
    -BaselineRelease '<冻结版项目>/bin/Release' `
    -CurrentRelease '<修复版项目>/bin/Release' `
    -Catalog '<已备份的 catalog.db>'
```

也可传 `-Project` 指定修复版仓库。`-ReplayParent` 指定复验工作目录的父目录，默认使用系统临时目录。每次运行都创建新子目录并保留中间数据；请预留快照和构建所需空间。`-Suite` 支持选择一个或多个专项，如 `-Suite english,presentation`（在 PowerShell 中用 `&` 调用脚本）。

## 安全准备快照

对正在使用的 SQLite 词库，可让脚本打开只读连接，通过 SQLite Online Backup 取得已提交的一致快照。快照写进本轮临时目录，并执行 `PRAGMA integrity_check` 和 SHA-256 核对。以下命令中的路径需换为原词库的实际位置。

```powershell
& ./.data/translation-audit-20261122/replay.ps1 -SourceDatabase '<原词库>/dictionaries.db'
```

若已持有独立快照，可先执行 `Get-FileHash -Algorithm SHA256 -LiteralPath '<快照>/catalog.db'` 与上表核对，再通过 `-Catalog` 指定。活动数据库的最新提交可能仍在 WAL 中，使用上面的在线备份入口可一同取得。快照哈希不同会终止运行，诊断消息会给出实际哈希和备份路径；重新导入相同 MDX、用不同 SQLite 版本生成备份、改变词库版本或设置，都可能产生不同的数据库文件。读音首选的写入和清除使用专项新建的小词库。

## 专项入口与输出

| 专项 | 探针和判定 | 本轮对照 |
| --- | --- | --- |
| `primary` | `run.ps1 -Bin <命令行输出目录> -Round <轮次>` 检查目标词条和原始正文；`definitions.py <轮次>` 独立检查三省堂首义 | `baseline`、`holdout-baseline`、`final`、`holdout`；首义文件加 `gloss-` |
| `hanying` | `run.ps1` 参数同上，检查纯中文查询、原始编号、释义和参见目标 | 主样本与保留样本各有前后对照 |
| `english` | `audit.py <轮次> <命令行输出目录>` 使用快照与实际检索候选；第二种子排除已选的同类输入，另附词形注释专项 | `baseline/final`、`holdout-baseline/holdout-final`、`gloss-baseline/gloss-final` |
| `japanese` | `run.ps1 -Stage <baseline或final> -AssemblyDirectory <命令行输出目录>`；加 `-Analytic` 跑补充形态。随后 `summarize.py` 汇总 | 主样本、补充样本、逐条排名和保留的未通过项 |
| `presentation` | `audit.ps1 -Stage <baseline或final>` 调用 WPF 运行时，检查多义摘要、子标题、同音词、首选和离屏滚动 | `baseline.jsonl`、`final.jsonl` |
| `shogakukan` | `run.ps1 -Stage <baseline或final>` 写 observed 数据并自动调用 `evaluate.py`；`-Continuation`、`-Strict` 分别运行两组续义检查 | 首义与两组续义的前后结果 |

这里的“命令行输出目录”指含 `E_Search.dll` 及其依赖的 `bin/Release/net10.0`。离屏 WPF 使用 `bin/Release/net10.0-windows`，需保留完整目录。临时复验项目会按旧探针约定准备 `japanese/baseline-bin`、`presentation/baseline-release/net10.0-windows` 以及项目根目录的 `bin/Release`。不同版本的探针分别启动独立进程。

`replay-builds.json` 记录实际使用的四个程序集与快照的 SHA-256。不同 SDK 或构建路径可能使程序集哈希改变；按相同 Git 源重建时，可同时检查逐条结果。`replay-comparison.json` 通过专项、输入、期望值和通过标志核对复跑与包内的每项判定。控制台的 `MATCH` 表示与冻结结果一致，包括本来就未通过的用例。耗时受设备负载、缓存和桌面布局影响，单独保存在逐行记录中。

## 预热耗时对照

时间记录位于 `primary/timing-{old1,new1,new2,old2}.jsonl`。这一独立对照按旧、新、新、旧的顺序，在各自的新 PowerShell 进程中运行 `primary/latency.ps1 -Bin <对应的 net10.0 目录> -Label <轮次>`。使用与 `primary/run.ps1` 相同的 .NET 10 宿主。每轮先查一遍 1,000 个保留词头预热，再查相同 1,000 个词头计时。完整质量报告还包含普通审计过程中的单次耗时。不同机器和运行时负载会产生不同的耗时。