param([ValidateSet('baseline','final')][string]$Stage='baseline',[switch]$Worker)
$ErrorActionPreference='Stop'
$root=(Resolve-Path (Join-Path $PSScriptRoot '../../..')).Path
$release=if ($Stage -eq 'baseline') {Join-Path $PSScriptRoot 'baseline-release'} else {Join-Path $root 'bin/Release'}
$libdir=Join-Path $release 'net10.0-windows'
if (!$Worker) {
    $dotnet=(Get-Command dotnet -ErrorAction Stop).Source
    if ($env:DOTNET_ROOT -and (Test-Path "$env:DOTNET_ROOT/dotnet.exe")) {$dotnet="$env:DOTNET_ROOT/dotnet.exe"}
    & $dotnet exec --runtimeconfig (Join-Path $libdir 'E_Search.runtimeconfig.json') --depsfile (Join-Path $PSHOME 'pwsh.deps.json') (Join-Path $PSHOME 'pwsh.dll') -STA -NoProfile -File $PSCommandPath -Stage $Stage -Worker
    exit $LASTEXITCODE
}
Add-Type -AssemblyName PresentationFramework
[AppContext]::SetData('APP_CONTEXT_BASE_DIRECTORY',$libdir)
foreach($lib in 'SQLitePCLRaw.core','SQLitePCLRaw.provider.winsqlite3','Microsoft.Data.Sqlite','E_Search'){
    $asm=[Reflection.Assembly]::LoadFrom((Join-Path $libdir "$lib.dll"))
}
[SQLitePCL.raw]::SetProvider([SQLitePCL.SQLite3Provider_winsqlite3]::new())
$db=(Resolve-Path (Join-Path $PSScriptRoot '../catalog.db')).Path
$ctor=$asm.GetType('DictionaryStore').GetConstructor([type[]]@([string],[bool]))
$store=$ctor.Invoke([object[]]@([string]$db,$true))
$token=[Threading.CancellationToken]::None
$any=[System.Management.Automation.Language.NullString]::Value
$writer=[IO.StreamWriter]::new((Join-Path $PSScriptRoot "$Stage.jsonl"),$false,[Text.UTF8Encoding]::new($false))
$writer.AutoFlush=$true
function AsJson($v) { ConvertTo-Json -InputObject $v -Compress -Depth 8 }
function SaveRow($suite,$query,$expected,$actual,$watch) {
    $elapsed=[Math]::Round($watch.Elapsed.TotalMilliseconds,3)
    $ok=(AsJson $expected) -ceq (AsJson $actual)
    $row=[ordered]@{suite=$suite;query=$query;expected=$expected;actual=$actual;pass=$ok;ms=$elapsed}
    $writer.WriteLine((AsJson $row))
}
$anchorProperty=$asm.GetType('LookupEntry').GetProperty('Anchor',[Reflection.BindingFlags]'Instance,NonPublic')
try {
    foreach($json in [IO.File]::ReadLines((Join-Path $PSScriptRoot 'cases.jsonl'))) {
        $c=ConvertFrom-Json -AsHashtable $json
        $watch=[Diagnostics.Stopwatch]::StartNew()
        try {
            switch ($c.suite) {
                oxford_multi_sense {
                    $hits=$store.Search($c.query,'oxford',$token)
                    $hit=@($hits | Where-Object { $_.Entry.EntryId -eq $c.ordinal })[0]
                    $actual=$hit.Display
                }
                oxford_subentry_anchor {
                    $hits=$store.Search($c.query,'oxford',$token)
                    $actual=$null
                    foreach($h in $hits) {
                        if ($h.Entry.EntryId -ne $c.ordinal -or !($anchor=$anchorProperty.GetValue($h.Entry))) {continue}
                        $raw=$store.CurrentBody($h.Entry)
                        $t=$anchor.Title.GetOffsetAndLength($raw.Length)
                        $s=$anchor.Sense.GetOffsetAndLength($raw.Length)
                        $title=[Net.WebUtility]::HtmlDecode([Regex]::Replace($raw.Substring($t.Item1,$t.Item2),'<[^>]*>','')).Trim()
                        $sense=[Net.WebUtility]::HtmlDecode([Regex]::Replace($raw.Substring($s.Item1,$s.Item2),'<[^>]*>','')).Trim().TrimStart('•',' ').Trim()
                        $candidate=[ordered]@{head=$h.Entry.Headword;title=$title;sense=$sense}
                        if ($null -eq $actual) { $actual=$candidate }
                        if ($title -ceq $c.expected.title -and $sense -ceq $c.expected.sense) {$actual=$candidate;break}
                    }
                }
                jp_homophone_preview {
                    $hits=$store.Search($c.query,$any,$token)
                    $additional=[Lookup]::AdditionalPreviews($hits)
                    $actual=@()
                    foreach($display in @($hits[0].Display)+@($additional)) {
                        $match=@($hits | Where-Object Display -ceq $display)[0]
                        if (!$match) {$actual+=@{display=$display};continue}
                        $e=$match.Entry
                        $actual+=([ordered]@{head=$e.Headword;reading=$e.Reading;book=$e.DictionaryId;id=$e.EntryId})
                    }
                }
            }
        } catch { $actual=@{exception=$_.Exception.Message} }
        SaveRow $c.suite $c.query $c.expected $actual $watch
    }

    # 在新建小词库中设置、重启读连接、调整来源并清除。真实快照仅只读。
    $tmp=Join-Path $PSScriptRoot ("prefs-"+$Stage+"-"+[guid]::NewGuid().ToString('N')+'.db')
    $wr=$ctor.Invoke([object[]]@([string]$tmp,$false));$rd=$null
    try {
        $A=Join-Path $PSScriptRoot 'audit-primary.tsv'
        $B=Join-Path $PSScriptRoot 'audit-secondary.tsv'
        [IO.File]::WriteAllLines($A,@("head`tgloss`treading","橋`t桥`tはし","箸`t筷子`tはし","端`t边缘`tはし"))
        [IO.File]::WriteAllLines($B,@("head`tgloss`treading","箸`t食箸`tハシ","橋`t桥梁`tハシ"))
        $map=[Activator]::CreateInstance($asm.GetType('TableMapping'),@(0,1,2,$true))
        $a=$wr.ImportDictionary($A,'ja',$map); $b=$wr.ImportDictionary($B,'ja',$map)
        $wr.SaveDictionaryOrder([string[]]@($a.Id,$b.Id))
        $watch=[Diagnostics.Stopwatch]::StartNew()
        $before=$wr.Search('hashi',$any,$token)
        SaveRow 'jp_preference' 'before' '橋' $before[0].Entry.Headword $watch
        $chosen=@($before | Where-Object {$_.Entry.Headword -eq '箸'})[0]
        $watch.Restart();$saved=$wr.SetReadingPreference($chosen,$false)
        SaveRow 'jp_preference' 'set 箸' $true $saved $watch
        $rd=$ctor.Invoke([object[]]@([string]$tmp,$true))
        foreach($word in 'hashi','はし','ハシ') {
            $watch.Restart();$r=$rd.Search($word,$any,$token)
            SaveRow 'jp_preference' "reopen $word" '筷子|食箸' "$($r[0].Entry.Gloss)|$($r[1].Entry.Gloss)" $watch
        }
        $watch.Restart();$ok=$wr.SetReadingPreference($rd.Search('ハシ',$any,$token)[0],$true)
        SaveRow 'jp_preference' 'clear 箸' $true $ok $watch
        $watch.Restart();$rd.Dispose();$rd=$ctor.Invoke([object[]]@([string]$tmp,$true))
        SaveRow 'jp_preference' 'reopen after clear' '橋' $rd.Search('はし',$any,$token)[0].Entry.Headword $watch
    } finally {if ($rd) {$rd.Dispose()};$wr.Dispose()}

    # 离屏 STA 窗口显示真实 WPF 文本布局，无托盘、无热键、无用户文件查询。
    $window=[ESearch.SearchWindow]::new($db,'oxford')
    $window.ShowActivated=$false;$window.ShowInTaskbar=$false;$window.WindowStartupLocation='Manual'
    $window.Top=-32000;$window.Left=-32000;$window.Topmost=$false;$window.Opacity=0;$window.Show()
    $flags=[Reflection.BindingFlags]'Instance,NonPublic'
    $wt=$window.GetType();$timer=$wt.GetField('debounce',$flags).GetValue($window)
    $qbox=$window.FindName('QueryBox');$body=$window.FindName('EntryText');$scroll=$window.FindName('DetailScroll')
    $picker=$window.FindName('CandidatePicker')
    [Threading.SynchronizationContext]::SetSynchronizationContext([Windows.Threading.DispatcherSynchronizationContext]::new($window.Dispatcher))
    function Until($condition) {
        $deadline=[DateTime]::UtcNow.AddSeconds(12)
        do {
            $frame=[Windows.Threading.DispatcherFrame]::new()
            [void]$window.Dispatcher.BeginInvoke([Windows.Threading.DispatcherPriority]::Background,[Action]{$frame.Continue=$false})
            [Windows.Threading.Dispatcher]::PushFrame($frame)
            if (& $condition) {return}
            Start-Sleep -Milliseconds 10
        } while ([DateTime]::UtcNow -lt $deadline)
        throw "WPF 等待超时: $condition"
    }
    foreach($word in 'ran out of','turned it off','ran across') {
        $watch=[Diagnostics.Stopwatch]::StartNew()
        $expected=[ordered]@{complete=$true;marked=2;bothVisible=$true;scrolled=$true}
        try {
            $qbox.Text=$word;$timer.Stop();$rev=$wt.GetField('revision',$flags).GetValue($window)
            $task=$wt.GetMethod('SearchDictionaryAsync',$flags).Invoke($window,@($word,$rev,$token))
            Until {$task.IsCompleted};[void]$task.GetAwaiter().GetResult()
            $wt.GetMethod('ToggleDetails',$flags).Invoke($window,@())
            Until {$body.Inlines.Count -eq 5 -and $scroll.VerticalOffset -gt 0}
            $window.UpdateLayout()
            $raw=$store.CurrentBody($picker.SelectedItem.Hit.Entry)
            # 独立从 HTML 得到可读全文；WPF 实际 Inline 拼接应与之完全相等。
            $plain=[Net.WebUtility]::HtmlDecode([Regex]::Replace([Regex]::Replace($raw,'<(?:br\b[^>]*|/p\s*|/div\s*|/li\s*|/tr\s*)>',"`n",'IgnoreCase'),'</?[a-zA-Z][^>]*>',''))
            $all=($plain -split '[\r\n]' | ForEach-Object {$_.Trim()} | Where-Object {$_}) -join [Environment]::NewLine
            $runs=@($body.Inlines);$complete=(($runs | ForEach-Object Text) -join '') -ceq $all
            $marked=@($runs | Where-Object {$_.FontWeight -eq [Windows.FontWeights]::Bold -and $_.Background}).Count
            $visible=$true
            foreach($ix in 1,3) {
                $r=$runs[$ix]
                $t=$r.ContentStart.GetCharacterRect([Windows.Documents.LogicalDirection]::Forward).Top-$scroll.VerticalOffset
                $e=$r.ContentEnd.GetCharacterRect([Windows.Documents.LogicalDirection]::Backward).Bottom-$scroll.VerticalOffset
                $visible=$visible -and $t -ge -0.5 -and $e -le ($scroll.ViewportHeight+0.5)
            }
            $actual=[ordered]@{complete=$complete;marked=$marked;bothVisible=$visible;scrolled=($scroll.VerticalOffset -gt 0)}
        } catch {$actual=@{exception=$_.Exception.Message}}
        SaveRow 'wpf_subentry' $word $expected $actual $watch
    }
    $window.Hide()
} finally {$writer.Dispose();$store.Dispose()}
