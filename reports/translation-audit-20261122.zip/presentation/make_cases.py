"""Build reproducible test cases using only SQLite and Python's HTMLParser. No product assembly needed."""
from pathlib import Path
from html.parser import HTMLParser
from html import unescape
import sqlite3, re, random, json, unicodedata
from bisect import bisect_right
from collections import defaultdict

here=Path(__file__).resolve().parent
db=sqlite3.connect((here.parent/'catalog.db').as_uri()+'?mode=ro&immutable=1',uri=True)
rng=random.Random(20261122)
cases=[]

class Words(HTMLParser):
    def __init__(self,raw):
        super().__init__(convert_charrefs=True)
        self.raw=raw
        self.row=[0]+[m.end() for m in re.finditer('\n',raw)]
        self.open=defaultdict(list)
        self.font=[];self.span=[];self.div=[]
        self.feed(raw);self.close()
    def position(self):
        row,col=self.getpos();return self.row[row-1]+col
    def handle_starttag(self,t,attrs):
        if t in ('font','span','div'):
            i=self.position()
            self.open[t].append((i,i+len(self.get_starttag_text()),dict(attrs)))
    def handle_endtag(self,t):
        if t in ('font','span','div') and self.open[t]:
            i,body,attrs=self.open[t].pop()
            end=self.position()
            value=unescape(re.sub(r'<[^>]*>','',self.raw[body:end])).strip()
            getattr(self,t).append((i,end,attrs,value))
    def entries(self):
        notes=[(lo,hi) for lo,hi,_,txt in self.div if re.match(r'^【(?:HELP|ORIGIN)】',txt)]
        sections=[(m.start(),m.group(1)) for m in re.finditer(r'【(PHR V|IDIOMS)】',self.raw)]
        tags=[]
        for lo,hi,attrs,txt in self.font:
            color=attrs.get('color','').lower()
            if color=='darkred' and re.fullmatch('[a-z. -]+',txt):
                sections.append((lo,'main'))
                tags.append((lo,'pos',txt))
            if color=='#ff5000' and not any(a<=lo<b for a,b in notes):
                txt=txt.lstrip('• ').strip()
                if txt:tags.append((lo,'sense',txt))
        sections.sort();where=[x[0] for x in sections]
        def section(i):
            n=bisect_right(where,i)-1
            return sections[n][1] if n>=0 else 'main'
        senses=[];pos=''
        for i,kind,value in sorted(tags):
            if kind=='pos':pos=value
            elif section(i)=='main':senses.append((pos,value))
        phrases=[]
        titles=[(lo,hi,txt) for lo,hi,a,txt in self.span if 'color:blue' in a.get('style','').replace(' ','').lower() and txt.startswith('◘')]
        title_bounds=sorted({lo for lo,_,_ in titles} | set(where))
        glosses=sorted((i,t) for i,k,t in tags if k=='sense')
        for lo,hi,txt in titles:
            if section(lo)!='PHR V':continue
            bound=bisect_right(title_bounds,lo)
            until=title_bounds[bound] if bound<len(title_bounds) else len(self.raw)
            found=next(((i,v) for i,v in glosses if hi<i<until),None)
            if found and 'color:#04f' not in self.raw[hi:found[0]].lower():
                phrases.append((txt[1:].strip(),found[1],lo))
        return senses,phrases

records=db.execute("select ordinal,head from entries where dict='oxford' and link is null order by ordinal").fetchall()
rng.shuffle(records)
fixed=['light','bank','drive','star','paper','rock','watch','bridge','change','book','water','record','arm','cool','fair','fine','field','last','fall','cover','press','close','run','turn','take','look','break','bring','stand','get','go','hold','put','carry','come','call','cut','give','pick','hang','keep','pass','sit','set','lay','make','work','move','clear','fill','fold']
fixed_rank={q:i for i,q in enumerate(fixed)}
records.sort(key=lambda x:fixed_rank.get(x[1],len(fixed)))
pos_labels={'noun':'n.','verb':'v.','adjective':'adj.','adverb':'adv.','preposition':'prep.','pronoun':'pron.'}
summary=anchor=0
seen_s=set();seen_a=set()
for ordinal,head in records:
    if summary>=360 and anchor>=100:break
    if not re.fullmatch(r'[a-z]+',head):continue
    raw,=db.execute("select raw from entries where dict='oxford' and ordinal=?",(ordinal,)).fetchone()
    if raw.lower().count('#ff5000')<2:continue
    parser=Words(raw);senses,phrases=parser.entries()
    if senses and summary<360 and head not in seen_s:
        first=senses[0]
        others=[x for x in senses if x[1]!=first[1]]
        if others:
            second=next((x for x in others if x[0] and first[0] and x[0]!=first[0]),others[0])
            left=(pos_labels.get(first[0],first[0])+' ' if first[0] else '')+first[1]
            right=(pos_labels.get(second[0],second[0])+' ' if second[0] and second[0]!=first[0] else '')+second[1]
            # Freeze independently verifiable untruncated text and a few long two-sided summaries.
            ll=min(len(left),max(33,67-len(right)));rr=67-ll
            fit=lambda text,n:text if len(text)<=n else text[:n-1]+'…'
            if not any(unicodedata.combining(ch) for ch in left+right):
                cases.append(dict(suite='oxford_multi_sense',query=head,expected=fit(left,ll)+' / '+fit(right,rr),ordinal=ordinal,sources=[first,second]))
                seen_s.add(head);summary+=1
    if anchor<100:
        rng.shuffle(phrases)
        for title,gloss,offset in phrases[:18]:
            cleaned=title.replace("'","").replace("7","").strip().lower()
            m=re.fullmatch(r'([a-z]+ (?:down|out|up|in|back|into|off|through|away|over|after|on|across|around|along|to|under|aside|about))(?: (?:sb|sth)(?: / (?:sb|sth))?)?',cleaned)
            if not m:continue
            key=m[1]
            if key in seen_a or not key.startswith(head+' '):continue
            if db.execute("select 1 from terms where dict='oxford' and kind=0 and term=? limit 1",(key,)).fetchone(): continue
            cases.append(dict(suite='oxford_subentry_anchor',query=key,expected=dict(head=key,title=title,sense=gloss),ordinal=ordinal,sourceOffset=offset))
            seen_a.add(key);anchor+=1
            if anchor>=100:break

def norm(s):return unicodedata.normalize('NFKC',s).lower()
def reading(s):return ''.join(chr(ord(ch)-96) if 'ァ'<=ch<='ヶ' else ch for ch in norm(s))
terms=db.execute("select distinct term from terms where kind=1 and dict='shogakukan' order by term").fetchall()
rng.shuffle(terms)
terms=[('はし',),('いし',),('かみ',),('あめ',),('こうしょう',)]+terms
seen=set()
for (term,) in terms:
    if term in seen or not re.fullmatch('[ぁ-ゖー]{2,9}',term):continue
    matches=db.execute("""select e.dict,e.ordinal,e.head,e.reading,t.kind,e.link from terms t
      join entries e using(dict,ordinal) join dictionaries d on d.id=e.dict
      where t.term=? order by d.priority,e.dict,e.ordinal""",(term,)).fetchall()
    if not matches or any(link or (kind==0 and (not y or reading(y)!=term or norm(h)==term)) for _,_,h,y,kind,link in matches): continue
    unique=[];keys=set();distinct_origins=set();n=0
    for book,index,head,y,kind,_ in matches:
        if kind!=1 or not y or reading(y)!=term: continue
        n+=1
        if (norm(head),reading(y)) not in keys:
            unique.append(dict(head=head,reading=y,book=book,id=index))
            keys.add((norm(head),reading(y)))
        distinct_origins.add(book)
    if len(unique)<2 or len(distinct_origins)<2:continue
    cases.append(dict(suite='jp_homophone_preview',query=term,expected=unique[:3],sourceCount=n))
    seen.add(term)
    if len(seen)>=140:break
(here/'cases.jsonl').write_text(''.join(json.dumps(row,ensure_ascii=False)+'\n' for row in cases),'utf-8')
print(f'Seed 20261122, {summary} Oxford summaries, {anchor} Oxford subentries, {len(seen)} Japanese readings.')
