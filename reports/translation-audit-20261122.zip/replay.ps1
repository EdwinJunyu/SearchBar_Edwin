#requires -Version 7.2
[CmdletBinding()]
param(
    [string] $Project = (Join-Path $PSScriptRoot '../..'),
    [string] $Catalog = (Join-Path $PSScriptRoot 'catalog.db'),
    [string] $SourceDatabase,
    [string] $BaselineRelease,
    [string] $CurrentRelease,
    [string] $ReplayParent = [IO.Path]::GetTempPath(),
    [ValidateSet('primary','english','japanese','presentation','hanying','shogakukan')]
    [string[]] $Suite = @('primary','english','japanese','presentation','hanying','shogakukan')
)
$ErrorActionPreference='Stop'
if (!$IsWindows) { throw '本次复验需要 Windows x64 和可用的 WPF 桌面。' }
$projectPath=(Resolve-Path -LiteralPath $Project).Path
$python=(Get-Command python -CommandType Application -ErrorAction Stop | Select-Object -First 1).Source
$pwshHost=(Get-Command pwsh -CommandType Application -ErrorAction Stop | Select-Object -First 1).Source
$hostDir=Split-Path $pwshHost
$dotnet=if ($env:DOTNET_ROOT -and (Test-Path -LiteralPath "$env:DOTNET_ROOT/dotnet.exe")) { "$env:DOTNET_ROOT/dotnet.exe" }
elseif (Test-Path -LiteralPath "$projectPath/.tools/dotnet/dotnet.exe") { "$projectPath/.tools/dotnet/dotnet.exe" }
else { (Get-Command dotnet -CommandType Application -ErrorAction Stop | Select-Object -First 1).Source }
$env:DOTNET_ROOT=Split-Path $dotnet
$sha='43d8b02924e04759394dcebe7ccb42d295c24bb9'
$snapshotHash='BDB0C8B50C85E6441F96B76A7309FEA5520E7B4107BE04D36C3DDB79511D8E9E'
$run=Join-Path ([IO.Path]::GetFullPath($ReplayParent)) ('E_Search-replay-'+[Guid]::NewGuid().ToString('N'))
$work=Join-Path $run '.data/translation-audit-20261122'
[void][IO.Directory]::CreateDirectory($work)
Write-Host "独立复验目录 $work"
function Exec([string]$exe,[string[]]$arguments) {
    & $exe @arguments
    if ($LASTEXITCODE -ne 0) { throw "命令失败，退出码 $LASTEXITCODE：$exe $($arguments -join ' ')" }
}
# 包内冻结清单决定要跑的输入。只复制脚本和用例，不复制既有结果。
foreach ($section in $Suite) {
    $dir=Join-Path $work $section
    [void][IO.Directory]::CreateDirectory($dir)
    foreach ($file in Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot $section) -File) {
        if ($file.Extension -in '.ps1','.py' -or $file.Name -match '^(?:(?:holdout-|gloss-|continuation-(?:strict-)?)?cases(?:-analytic)?\.jsonl?|sample\.jsonl)$') {
            Copy-Item -LiteralPath $file.FullName -Destination $dir
        }
    }
}

$snapshot=Join-Path $work 'catalog.db'
if ($SourceDatabase) {
    # SQLite Online Backup 从同一已提交快照读取，保留 WAL 中已提交的数据。目标是本次运行的新文件。
    $backup=@'
import pathlib, sqlite3, sys
src, dst = map(lambda p: pathlib.Path(p).resolve(), sys.argv[1:])
if not src.is_file() or dst.exists():
    raise RuntimeError("Expected an existing source and a new destination")
a = sqlite3.connect(src.as_uri()+"?mode=ro", uri=True)
b = sqlite3.connect(dst)
try:
    a.backup(b)
    if b.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
        raise RuntimeError("Snapshot failed integrity_check")
finally:
    b.close()
    a.close()
'@
    Exec $python @('-X','utf8','-c',$backup,(Resolve-Path -LiteralPath $SourceDatabase).Path,$snapshot)
} else {
    $catalogPath=(Resolve-Path -LiteralPath $Catalog).Path
    if ((Test-Path -LiteralPath "$catalogPath-wal") -and (Get-Item -LiteralPath "$catalogPath-wal").Length -gt 0) {
        throw '该文件有未并入主文件的 WAL；请改用 -SourceDatabase，让 SQLite 创建一致快照。'
    }
    Copy-Item -LiteralPath $catalogPath -Destination $snapshot
}
$snapshotActual=(Get-FileHash -LiteralPath $snapshot).Hash
if ($snapshotActual -ne $snapshotHash) {
    throw "快照 SHA-256 与本次审计不同：$snapshotActual。请使用报告对应的 catalog.db；本次备份保存在 $snapshot。"
}

function BuildRelease([string]$folder) {
    Exec $dotnet @('build',(Join-Path $folder 'E_Search.csproj'),'-c','Release','-p:NuGetAudit=false')
}
function CheckRelease([string]$folder) {
    foreach ($target in 'net10.0','net10.0-windows') {
        foreach ($file in 'E_Search.dll','E_Search.runtimeconfig.json','Microsoft.Data.Sqlite.dll') {
            if (!(Test-Path -LiteralPath (Join-Path $folder "$target/$file"))) { throw "Release 缺少 $target/$file，目录 $folder" }
        }
    }
}
if (!$BaselineRelease) {
    $tree=Join-Path $run 'baseline-source'
    $archive=Join-Path $run 'baseline-source.zip'
    Exec 'git' @('-C',$projectPath,'archive','--format=zip',"--output=$archive",$sha)
    Expand-Archive -LiteralPath $archive -DestinationPath $tree
    $cache=Join-Path $projectPath '.tools/everything/Everything-SDK.zip'
    if (Test-Path -LiteralPath $cache) {
        $target=Join-Path $tree '.tools/everything'
        [void][IO.Directory]::CreateDirectory($target)
        Copy-Item -LiteralPath $cache -Destination $target
    }
    BuildRelease $tree
    $BaselineRelease=Join-Path $tree 'bin/Release'
}
if (!$CurrentRelease) {
    BuildRelease $projectPath
    $CurrentRelease=Join-Path $projectPath 'bin/Release'
}
$baseline=(Resolve-Path -LiteralPath $BaselineRelease).Path
$current=(Resolve-Path -LiteralPath $CurrentRelease).Path
if ($baseline -eq $current) { throw '修复前后必须使用两个独立的 Release 目录。' }
CheckRelease $baseline
CheckRelease $current
$stagedCurrent=Join-Path $run 'bin/Release'
[void][IO.Directory]::CreateDirectory($stagedCurrent)
# 部分原始探针按项目位置寻找 bin/Release，在临时项目内重建相同的布局。
foreach ($target in 'net10.0','net10.0-windows') {
    Copy-Item -LiteralPath (Join-Path $current $target) -Destination $stagedCurrent -Recurse
}
$oldCli=Join-Path $baseline 'net10.0'
$newCli=Join-Path $stagedCurrent 'net10.0'
if ('presentation' -in $Suite) {
    $oldUi=Join-Path $work 'presentation/baseline-release'
    [void][IO.Directory]::CreateDirectory($oldUi)
    Copy-Item -LiteralPath (Join-Path $baseline 'net10.0-windows') -Destination $oldUi -Recurse
}
if ('japanese' -in $Suite -or 'shogakukan' -in $Suite) {
    $oldJp=Join-Path $work 'japanese/baseline-bin'
    [void][IO.Directory]::CreateDirectory((Split-Path $oldJp))
    Copy-Item -LiteralPath $oldCli -Destination $oldJp -Recurse
}
$versions=[ordered]@{
    baseline_commit=$sha; snapshot_sha256=$snapshotActual
    baseline_cli=(Get-FileHash "$oldCli/E_Search.dll").Hash
    baseline_wpf=(Get-FileHash (Join-Path $baseline 'net10.0-windows/E_Search.dll')).Hash
    current_cli=(Get-FileHash "$newCli/E_Search.dll").Hash
    current_wpf=(Get-FileHash (Join-Path $stagedCurrent 'net10.0-windows/E_Search.dll')).Hash
}
$versions | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $work 'replay-builds.json') -Encoding utf8
function Probe([string]$bin,[string]$script,[string[]]$parameters) {
    Exec $dotnet (@('exec','--runtimeconfig',"$bin/E_Search.runtimeconfig.json",'--depsfile',"$hostDir/pwsh.deps.json","$hostDir/pwsh.dll",'-NoProfile','-File',(Join-Path $work $script))+$parameters)
}
foreach ($section in $Suite) {
    Write-Host "复验 $section"
    switch ($section) {
        {$_ -in 'primary','hanying'} {
            foreach ($round in 'baseline','holdout-baseline','final','holdout') {
                $bin=if ($round.EndsWith('baseline')) {$oldCli} else {$newCli}
                Probe $bin "$section/run.ps1" @('-Bin',$bin,'-Round',$round)
                if ($section -eq 'primary') { Exec $python @('-X','utf8',"$work/primary/definitions.py",$round) }
            }
        }
        'english' {
            foreach ($round in 'baseline','holdout-baseline','gloss-baseline','final','holdout-final','gloss-final') {
                $bin=if ($round.EndsWith('baseline')) {$oldCli} else {$newCli}
                Exec $python @('-X','utf8',"$work/english/audit.py",$round,$bin)
            }
        }
        'japanese' {
            foreach ($round in 'baseline','final') {
                $bin=if ($round -eq 'baseline') {$oldCli} else {$newCli}
                Probe $bin 'japanese/run.ps1' @('-Stage',$round,'-AssemblyDirectory',$bin)
                Probe $bin 'japanese/run.ps1' @('-Stage',$round,'-AssemblyDirectory',$bin,'-Analytic')
            }
            Exec $python @('-X','utf8',"$work/japanese/summarize.py")
        }
        'presentation' {
            foreach ($round in 'baseline','final') { Exec $pwshHost @('-NoProfile','-File',"$work/presentation/audit.ps1",'-Stage',$round) }
        }
        'shogakukan' {
            foreach ($round in 'baseline','final') {
                $bin=if ($round -eq 'baseline') {$oldCli} else {$newCli}
                Probe $bin 'shogakukan/run.ps1' @('-Stage',$round)
                if (Test-Path "$work/shogakukan/continuation-cases.json") { Probe $bin 'shogakukan/run.ps1' @('-Stage',$round,'-Continuation') }
                if (Test-Path "$work/shogakukan/continuation-strict-cases.json") { Probe $bin 'shogakukan/run.ps1' @('-Stage',$round,'-Strict') }
            }
        }
    }
}
$compare=@'
from pathlib import Path
from collections import Counter
import json, sys
actual, original = map(Path,sys.argv[1:3])
report=[]
for p in sorted(actual.glob("*/*.jsonl")):
    frozen=original/p.relative_to(actual)
    if not frozen.is_file(): continue
    def records(f):
        with f.open(encoding="utf-8-sig") as reader:
            return [r for line in reader if (r:=json.loads(line)).get("pass") is not None]
    got=records(p)
    if not got: continue
    ref=records(frozen)
    def score(rows):
        return Counter((r.get("suite"), r.get("query"), json.dumps(r.get("expected"),ensure_ascii=False,sort_keys=True), bool(r["pass"])) for r in rows)
    a,b=score(got),score(ref)
    report.append(dict(file=p.relative_to(actual).as_posix(), checks=len(got),passed=sum(bool(r["pass"]) for r in got),
                       matches_frozen_checks=a==b,missing_frozen_rows=sum((b-a).values()),new_rows=sum((a-b).values())))
if not report: raise RuntimeError("No comparable rows in the original package")
(actual/"replay-comparison.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf8")
for r in report: print(r["file"], f'{r["passed"]}/{r["checks"]}', "MATCH" if r["matches_frozen_checks"] else "DIFF")
'@
Exec $python @('-X','utf8','-c',$compare,$work,$PSScriptRoot)
Write-Host "逐条复验结果 $work"
