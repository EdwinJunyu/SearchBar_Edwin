"""Build a self-contained audit report and a ZIP of per-case evidence. Python standard library only."""
from base64 import b64encode
from collections import Counter, defaultdict
import csv, gzip, hashlib, html, json, math, sqlite3, zipfile
from pathlib import Path

root=Path(__file__).resolve().parent
repo=root.parents[1]
output=repo/'reports'
output.mkdir(exist_ok=True)
basename='translation-audit-20261122'
def records(path):
    return [json.loads(t) for t in path.read_text('utf-8-sig').splitlines() if t.strip()]
def sha(path):
    with path.open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()
def compact(x):
    return json.dumps(x,ensure_ascii=False,separators=(',',':'))
def esc(x): return html.escape(str(x),quote=True)
def number(n): return f'{n:,}'
def perc(n,total): return f'{100*n/total:.1f}%'
def qtile(values,q):
    arr=sorted(values)
    return arr[math.ceil(q*len(arr))-1]

# Each pair must have the same frozen query, criterion and target.
pairs=[]
def add(family,folder,before,after,split):
    a,b=(records(root/folder/(s+'.jsonl')) for s in [before,after])
    assert len(a)==len(b)>0, (folder,before,after)
    for old,new in zip(a,b,strict=True):
        for k in ['suite','query','expected']:
            assert old[k]==new[k],(folder,k,old,new)
        assert isinstance(old['pass'],bool) and isinstance(new['pass'],bool)
        pairs.append(dict(family=family,split=split,suite=new['suite'],query=new['query'],
                          expected=new['expected'],before=old['actual'],after=new['actual'],
                          old=old['pass'],new=new['pass'],old_ms=old.get('ms'),new_ms=new.get('ms'),
                          book=new.get('book',new.get('filter','')),source=folder+'/'+after+'.jsonl'))
for g,folder,b,a,split in [
    ('词头与正文','primary','baseline','final','主样本'),('词头与正文','primary','holdout-baseline','holdout','保留样本'),
    ('三省堂首义','primary','gloss-baseline','gloss-final','主样本'),('三省堂首义','primary','gloss-holdout-baseline','gloss-holdout','保留样本'),
    ('汉英纯中文查询','hanying','baseline','final','主样本'),('汉英纯中文查询','hanying','holdout-baseline','holdout','保留样本'),
    ('英语检索','english','baseline','final','主样本'),('英语检索','english','holdout-baseline','holdout-final','第二种子'),
    ('牛津词形注释','english','gloss-baseline','gloss-final','定向复核'),
    ('日语检索','japanese','baseline','final','主样本'),('日语检索','japanese','baseline-analytic','final-analytic','补充对照'),
    ('结果呈现','presentation','baseline','final','主样本'),
    ('小学馆首义','shogakukan','baseline','final','抽样复核'),
    ('小学馆首义','shogakukan','continuation-baseline','continuation-final','标签续行'),
    ('小学馆首义','shogakukan','continuation-strict-baseline','continuation-strict-final','同义表达续行')]:
    add(g,folder,b,a,split)
extra=root/'shogakukan/holdout.jsonl'
if extra.is_file(): add('小学馆首义','shogakukan','holdout-baseline','holdout','保留样本')

labels={'en_morphology':'英语词形还原','en_spelling':'单解错拼','en_spelling_ambiguous':'多解错拼','en_compound':'独立词组','en_reference':'词形与词典参见','en_phrasal':'内嵌连续短语','en_separable':'可分短语','en_negative_boundary':'标点边界对照','en_negative_noise':'无意义拼写对照','polite':'礼貌与否定','progressive':'进行体','passive':'被动语态','potential':'可能态','multistep':'多层活用','sentence':'句中日语原形与原片段','kana':'假名查询','negative':'畸形日语输入对照','romaji':'普通罗马字','romaji-long':'带长音的罗马字','potential-analytic':'ことができる 可能表达','oxford_multi_sense':'牛津两义摘要','jp_homophone_preview':'日语同音预览','oxford_subentry_anchor':'牛津子标题与义项定位','jp_preference':'同音首选持久化','wpf_subentry':'WPF 全文、高亮与滚动','hanying_subentry':'纯中文检索、英译与参见目标'}
def section_title(r):
    return labels.get(r['suite'],r['suite'] if r['family'] not in ('小学馆首义','牛津词形注释') else r['family'])
summary=defaultdict(list)
for r in pairs: summary[r['family']].append(r)
def stats(rows):
    return (len(rows),sum(r['old'] for r in rows),sum(r['new'] for r in rows),
            sum(not r['old'] and r['new'] for r in rows),sum(r['old'] and not r['new'] for r in rows))
n,old,new,gain,loss=stats(pairs)
def table(head,rows):
    return '<div class="scroller"><table><thead><tr>'+''.join(f'<th scope="col">{esc(c)}</th>' for c in head)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+esc(c)+'</td>' for c in row)+'</tr>' for row in rows)+'</tbody></table></div>'
def stat_table(groups):
    out=[]
    for name,rows in groups:
        count,pre,post,up,down=stats(rows)
        out.append((name,number(count),f'{number(pre)} ({perc(pre,count)})',f'{number(post)} ({perc(post,count)})',number(up),number(down)))
    return table(['验收项目','断言数','旧版通过','修复后通过','修复','回退'],out)
samples=records(root/'primary/sample.jsonl')
assert len(samples)==len({r['normalized'] for r in samples})==7000
bybook={'shogakukan':'小学馆日汉辞典','oxford':'牛津高阶英汉双解','hanying':'现代汉英综合大辞典','sanseido':'三省堂超级大辞林'}
db=sqlite3.connect((root/'catalog.db').resolve().as_uri()+'?mode=ro&immutable=1',uri=True)
book_rows=[]
for book,size,signature in db.execute('select id,records,sha256 from dictionaries order by priority'):
    subset=[r for r in summary['词头与正文'] if r['book']==book]
    hits=sum(r['after']['target_rank']==1 for r in subset)
    book_rows.append([bybook[book],number(size),number(len(subset)),number(sum(r['new'] for r in subset)),f'{number(hits)} ({perc(hits,len(subset))})'])
primary=summary['词头与正文']
p50,p95=(qtile([r['new_ms'] for r in primary],q) for q in (.5,.95))
base50,base95=(qtile([r['old_ms'] for r in primary],q) for q in (.5,.95))
grouped=defaultdict(list)
for r in pairs:
    name=r['family']+' · '+r['split']
    if r['family'] in ('结果呈现','日语检索','英语检索'): name+=' · '+section_title(r)
    grouped[name].append(r)
m=defaultdict(list)
for r in pairs: m[r['split']].append(r)
bad=[r for r in pairs if not r['new']]
residual={r['query']:r for r in json.loads((root/'japanese/summary.json').read_text('utf8'))['residual']}
def reason(r):
    j=residual.get(r['query'],{})
    if j.get('rank'): return f"目标排在第 {j['rank']} 位，未进前三个不同词头。"
    if '剥る'==j.get('expected',{}).get('headword'): return '索引也收录了同形的「剥れる」，未继续推断罕见原形「剥る」。'
    if j: return '由サ变词机械生成的表达，自然度存疑。原始严格判定保留。'
    if r['suite']=='oxford_multi_sense': return '修正后的预览与冻结的颜色标签预期不同。可在逐条结果查看两种文字。'
    if r['family']=='小学馆首义' and r['query']=='湿気': return '原书先写「湿気 →しっけ」，下一个词头「漆器」才译为「漆器」。人工对照确认程序参见正确，自动提取越过词头边界。'
    if r['family']=='小学馆首义' and r['query']=='留め螺子': return '旧预期只取第一行。原书下一行还有「螺钉」，修复版补全该词，因此超过原判定的长度。'
    return '逐条结果保存了期望值与两个版本的实际输出。'
def target_text(r):
    t=r['expected']
    return t.get('headword',t.get('glyphs',compact(t))) if isinstance(t,dict) else str(t)
examples=[]
def brief(x):
    if x is None: return '未找到目标记录'
    if isinstance(x,str): return x
    if isinstance(x,dict):
        if 'gloss' in x: return x['gloss']
        if 'display' in x: return x['display']
    if isinstance(x,list) and x and isinstance(x[0],dict) and 'display' in x[0]: return x[0]['display']
    return compact(x)
for f,term in [('汉英纯中文查询','张臂长度'),('三省堂首义','roadworthy'),('三省堂首义','般若隈'),('牛津词形注释','show'),('牛津词形注释','shown')]:
    for r in summary[f]:
        if r['query']==term:
            examples.append([term,brief(r['before']),brief(r['after'])]);break
ordered_fields=['family','split','suite','query','expected','before','after','old','new','old_ms','new_ms','book','source']
csv_file=root/'results.csv'
with csv_file.open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.writer(f);w.writerow(['组别','分组','测试项目','输入','期望值','修复前实际输出','修复后实际输出','修复前通过','修复后通过','修复前毫秒','修复后毫秒','词库筛选或目标','逐条记录'])
    for r in pairs:
        cells=[compact(r[k]) if isinstance(r[k],(list,dict)) else r[k] for k in ordered_fields]
        # Queries are dictionary/user-like text. Prevent office programs interpreting any as a formula.
        w.writerow(["'"+v if isinstance(v,str) and v.startswith(('=','+','-','@','\t','\r')) else v for v in cells])
# Compact offline case explorer. Data are the same rows exported to CSV.
payload=b64encode(gzip.compress(compact([[r['family'],r['split'],section_title(r),r['query'],r['expected'],r['before'],r['after'],r['old'],r['new']] for r in pairs]).encode(),mtime=0)).decode()
env=json.loads((root/'environment.json').read_text('utf8'))
bench=[]
for version in ('old','new'):
    runs=[records(root/'primary'/f'timing-{version}{run}.jsonl') for run in (1,2)]
    assert len(runs[0])==len(runs[1])==1000 and [r['query'] for r in runs[0]]==[r['query'] for r in runs[1]]
    times=[r['ms'] for run in runs for r in run]
    bench.append((qtile(times,.50),qtile(times,.95)))
report=(root/'template.html').read_text('utf8')
subs={
 'N':number(n),'OLD':number(old),'NEW':number(new),'RATE':perc(new,n),'FIXES':number(gain),'LOSSES':number(loss),'FAILS':number(n-new),
 'SUMMARY':stat_table(summary.items()),'GROUPS':stat_table(grouped.items()),'DICTS':table(['词库','快照记录数','不同词头','词头与正文均通过','目标排在首位'],book_rows),
 'EXAMPLES':table(['输入','旧版实际结果','修复后实际结果'],examples),
 'FAILTABLE':table(['输入','测试项目','期望目标','复核说明'],[(r['query'],section_title(r),target_text(r),reason(r)) for r in bad]),
 'P50':f'{p50:.2f}','P95':f'{p95:.2f}','B50':f'{base50:.2f}','B95':f'{base95:.2f}',
 'WARM':f"在同一批 1,000 个保留词头上另做串行计时。按旧版、修复版、修复版、旧版的顺序，各进程先预热一遍再计时一遍。合并每个版本的两轮，旧版中位数 / P95 为 {bench[0][0]:.2f} / {bench[0][1]:.2f} ms，修复版为 {bench[1][0]:.2f} / {bench[1][1]:.2f} ms。新版在这批查询上耗时有所增加。",
 'PAYLOAD':payload,'DATABASE':env['snapshot_sha256'],'ASSEMBLY':env['cli_sha256'],'GRPS':''.join('<option>'+esc(k)+'</option>' for k in summary),
 'ZIP':basename+'.zip','STATS':f'修复前 {number(old)} / {number(n)}（{perc(old,n)}），修复后 {number(new)} / {number(n)}（{perc(new,n)}）。',
 'DETAILS':(root/'findings.html').read_text('utf8') if (root/'findings.html').exists() else '',
}
for key,value in subs.items(): report=report.replace('{{'+key+'}}',value)
assert '{{' not in report
(output/(basename+'.html')).write_text(report,encoding='utf8')
# Exclude date-specific intermediate test DLLs, live databases and binary dictionary contents.
files=[root/name for name in ['README.md','replay.ps1','environment.json','results.csv','build_report.py','template.html','findings.html','regression.log']]
for folder in ['primary','english','japanese','presentation','hanying','shogakukan']:
    files.extend(p for p in sorted((root/folder).iterdir()) if p.is_file() and p.suffix in ('.json','.jsonl','.py','.ps1','.tsv') and
        'candidate' not in p.name and '-actual' not in p.name and not p.name.startswith('provisional'))
with zipfile.ZipFile(output/(basename+'.zip'),'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
    for f in files: z.write(f,f.relative_to(root))
with zipfile.ZipFile(output/(basename+'.zip')) as z:
    assert z.testzip() is None
print(compact({'checks':n,'old':old,'new':new,'improved':gain,'regressed':loss,'breakdown':{f:stats(g) for f,g in summary.items()},'latency':[base50,base95,p50,p95]}))

