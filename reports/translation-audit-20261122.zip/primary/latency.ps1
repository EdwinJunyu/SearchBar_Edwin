param([Parameter(Mandatory)][string]$Bin,[Parameter(Mandatory)][string]$Label)
$ErrorActionPreference='Stop'
$Bin=(Resolve-Path $Bin).Path
foreach ($lib in 'SQLitePCLRaw.core','SQLitePCLRaw.provider.winsqlite3','Microsoft.Data.Sqlite','E_Search'){
    $asm=[Reflection.Assembly]::LoadFrom((Join-Path $Bin "$lib.dll"))
}
[SQLitePCL.raw]::SetProvider([SQLitePCL.SQLite3Provider_winsqlite3]::new())
$db=$asm.GetType('DictionaryStore').GetConstructor([type[]]@([string],[bool])).Invoke([object[]]@((Resolve-Path (Join-Path $PSScriptRoot '../catalog.db')).Path,$true))
$any=[System.Management.Automation.Language.NullString]::Value
$token=[Threading.CancellationToken]::None
$words=@(Get-Content (Join-Path $PSScriptRoot 'sample.jsonl') | ConvertFrom-Json | Where-Object partition -eq 'holdout')
$writer=[IO.StreamWriter]::new((Join-Path $PSScriptRoot "timing-$Label.jsonl"),$false,[Text.UTF8Encoding]::new($false))
try {
    # First pass warms the DB connection, filesystem cache, and JIT on exactly the measured vocabulary.
    foreach($word in $words){$null=$db.Search($word.query,$any,$token)}
    $sw=[Diagnostics.Stopwatch]::new()
    foreach($word in $words){
        $sw.Restart()
        $hits=$db.Search($word.query,$any,$token)
        $sw.Stop()
        if($hits.Count -eq 0){throw "Missing searched headword $($word.query)"}
        $row=[ordered]@{query=$word.query;book=$word.book;ms=[math]::Round($sw.Elapsed.TotalMilliseconds,4)}
        $writer.WriteLine(($row|ConvertTo-Json -Compress))
    }
} finally {$db.Dispose();$writer.Dispose()}

