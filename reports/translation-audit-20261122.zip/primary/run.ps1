param([Parameter(Mandatory)][string]$Bin,[ValidateSet('baseline','final','holdout','holdout-baseline')][string]$Round)
$ErrorActionPreference='Stop'
$Bin=(Resolve-Path $Bin).Path
foreach($lib in 'SQLitePCLRaw.core','SQLitePCLRaw.provider.winsqlite3','Microsoft.Data.Sqlite','E_Search'){
    $assembly=[Reflection.Assembly]::LoadFrom((Join-Path $Bin "$lib.dll"))
}
[SQLitePCL.raw]::SetProvider([SQLitePCL.SQLite3Provider_winsqlite3]::new())
$database=(Resolve-Path (Join-Path $PSScriptRoot '../catalog.db')).Path
$db=$assembly.GetType('DictionaryStore').GetConstructor([type[]]@([string],[bool])).Invoke([object[]]@($database,$true))
$writer=[IO.StreamWriter]::new((Join-Path $PSScriptRoot "$Round.jsonl"),$false,[Text.UTF8Encoding]::new($false))
$count=0
$passed=0
$all=[System.Management.Automation.Language.NullString]::Value
$token=[Threading.CancellationToken]::None
try {
    foreach($line in [IO.File]::ReadLines((Join-Path $PSScriptRoot 'sample.jsonl'))){
        $case=ConvertFrom-Json -InputObject $line
        if (($case.partition -eq 'holdout') -ne $Round.StartsWith('holdout')) { continue }
        $expect="$($case.book):$($case.ordinal)"
        $watch=[Diagnostics.Stopwatch]::StartNew()
        try {
            $hits=$db.Search($case.query,$all,$token)
            $watch.Stop()
            $rank=0
            $match=$null
            foreach($hit in $hits) {
                $rank++
                if($hit.Entry.DictionaryId -ceq $case.book -and $hit.Entry.EntryId -eq $case.ordinal) { $match=$hit; break }
            }
            $rawOk=$false
            if($null -ne $match){
                $raw=$db.CurrentBody($match.Entry)
                if($null -ne $raw){
                    $rawOk=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([Text.Encoding]::UTF8.GetBytes($raw))) -ceq $case.raw_sha256
                }
            } else { $rank=0 }
            $first=$hits | Select-Object -First 1
            $ok=$rank -gt 0 -and $match.Method -ceq 'headword' -and $first.Method -ceq 'headword' -and $rawOk -and ![string]::IsNullOrWhiteSpace($match.Entry.Gloss)
            $actual=[ordered]@{target_rank=$rank; first_method=$first.Method; target_method=$match.Method; target_gloss=$match.Entry.Gloss; target_display=$match.Display; first_id="$($first.Entry.DictionaryId):$($first.Entry.EntryId)"; first_display=$first.Display; entries=$hits.Count; detail_hash_matches=$rawOk}
        } catch { $watch.Stop();$ok=$false;$actual=@{error=$_.Exception.ToString()} }
        $row=[ordered]@{suite='词头与详情';query=$case.query;book=$case.book;expected=$expect;actual=$actual;pass=$ok;ms=[Math]::Round($watch.Elapsed.TotalMilliseconds,4)}
        $writer.WriteLine(($row | ConvertTo-Json -Compress -Depth 6))
        $count++
        if($ok){$passed++}
    }
} finally { $writer.Dispose(); $db.Dispose() }
Write-Host "$Round $passed / $count"

