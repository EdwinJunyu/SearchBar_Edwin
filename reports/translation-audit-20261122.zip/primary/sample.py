"""Deterministic unique-headword sample. Run against a read-only snapshot."""
from pathlib import Path
import hashlib
import json
import sqlite3
import unicodedata

HERE = Path(__file__).resolve().parent
DB = HERE.parent / "catalog.db"
SEED = "E_Search:20261122:v1"
used = set()
items = []
conn = sqlite3.connect(DB.as_uri() + "?mode=ro&immutable=1", uri=True)
for book in ("oxford", "shogakukan", "hanying", "sanseido"):
    unique = {}
    rows = conn.execute("SELECT ordinal,head FROM entries WHERE dict=? AND link IS NULL ORDER BY ordinal", (book,))
    for ordinal, head in rows:
        key = unicodedata.normalize("NFKC", head).strip().lower()
        if key and key not in used:
            unique.setdefault(key, (ordinal, head))
    def score(key):
        return hashlib.sha256((SEED + "|" + book + "|" + key).encode()).digest()
    for i,key in enumerate(sorted(unique, key=score)[:1750]):
        ordinal, head = unique[key]
        raw, gloss = conn.execute("SELECT raw,gloss FROM entries WHERE dict=? AND ordinal=?", (book,ordinal)).fetchone()
        items.append(dict(book=book,ordinal=ordinal,query=head,partition="audit" if i<1500 else "holdout",
                          normalized=key,raw_sha256=hashlib.sha256(raw.encode()).hexdigest().upper(),source_gloss=gloss))
        used.add(key)
assert len(items)==len(used)==7000
items.sort(key=lambda x: score(x["normalized"]))
with (HERE/"sample.jsonl").open("w", encoding="utf-8") as out:
    for item in items: print(json.dumps(item,ensure_ascii=False), file=out)
conn.close()
