"""Score displayed glosses against real dictionary markup independently of the C# parser."""
import json
import re
import sqlite3
import sys
from html.parser import HTMLParser
from pathlib import Path

class Markup(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.lines = [[]]
        self.headers = []
        self.numbered = False
        self.body2 = False

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'br':
            self.lines.append([])
        if tag == 'body2':
            self.body2 = True
        if tag == 'font' and attrs.get('color','').upper() in ('#FF0000','#0000FF'):
            self.headers.append((len(self.lines)-1,attrs['color'].upper()))

    def handle_endtag(self, tag):
        if tag == 'body2':
            self.body2 = True

    def handle_data(self, data):
        self.lines[-1].append(data)
        if data.strip() == '(1)':
            self.numbered = True

def oracle(item,raw):
    p=Markup()
    p.feed(raw)
    lines=[''.join(parts).strip() for parts in p.lines]
    if item['book']=='sanseido' and not p.body2 and not p.numbered and p.headers:
        idx,color=p.headers[0]
        if idx!=0: return
        if color=='#FF0000':
            end=next((i for i,line in enumerate(lines[:2]) if '【' in line and line.endswith('】')),None)
            if end is None: return
        else:
            if not re.match(r'^\s*<font[^>]*>\s*<b>\s*<font',raw,re.I): return
            end=0
        senses=[line for line in lines[end+1:] if line]
        # A division heading or a standalone grammatical derivation is not a definition.
        while color=='#FF0000' and len(senses)>1:
            line=re.sub(r'^■[一二三四五六七八九十]+■\s*','',senses[0])
            if line and not (re.fullmatch(r'\((?:動|形|名|副|連|接|感|代|枕|助)[^)]*\)(?:スル|\[文\].*)?',line)
                             or re.fullmatch(r'\([^)]*動詞「[^」]+」の五段化\)',line)):
                break
            senses=senses[1:]
        text=next(iter(senses),'')
        if not text: return
        text = text.split('。')[0]+'。' if '。' in text else text.rstrip('；;').rstrip()
        return ('三省堂标题后首义',text)

def clip(s):
    prefix=s.encode('utf-16-le')[:140].decode('utf-16-le',errors='ignore')
    return prefix+'…' if prefix!=s else s

root=Path(__file__).resolve().parent
roundname=sys.argv[1]
db=sqlite3.connect((root.parent/'catalog.db').as_uri()+'?mode=ro&immutable=1',uri=True)
items={r['book']+':'+str(r['ordinal']):r for r in map(json.loads,(root/'sample.jsonl').read_text('utf8').splitlines())}
from collections import Counter
counts=Counter()
with (root/('gloss-'+roundname+'.jsonl')).open('w',encoding='utf8') as out:
    for row in map(json.loads,(root/(roundname+'.jsonl')).read_text('utf8').splitlines()):
        item=items[row['expected']]
        if item['book']!='sanseido': continue
        raw=db.execute('select raw from entries where dict=? and ordinal=?',(item['book'],item['ordinal'])).fetchone()[0]
        checked=oracle(item,raw)
        if not checked: continue
        suite,expected=checked
        expected=clip(expected)
        actual=row['actual']['target_gloss']
        ok=actual==expected
        print(json.dumps(dict(suite=suite,query=item['query'],book=item['book'],expected=expected,actual=actual,
                              source=item['raw_sha256'],ordinal=item['ordinal'],**{'pass':ok}),ensure_ascii=False),file=out)
        counts[suite,ok]+=1
print(counts)
