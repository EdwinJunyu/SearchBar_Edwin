param([Parameter(Mandatory)][string]$Bin,[Parameter(Mandatory)][string]$Out,[Parameter(Mandatory)][string]$Cases)
$ErrorActionPreference = 'Stop'
$Bin = (Resolve-Path -LiteralPath $Bin).Path
$catalog = (Resolve-Path (Join-Path $PSScriptRoot '../catalog.db')).Path
foreach ($name in 'SQLitePCLRaw.core','SQLitePCLRaw.provider.winsqlite3','Microsoft.Data.Sqlite','E_Search') {
    $asm = [Reflection.Assembly]::LoadFrom((Join-Path $Bin "$name.dll"))
}
[SQLitePCL.raw]::SetProvider([SQLitePCL.SQLite3Provider_winsqlite3]::new())
$store = $asm.GetType('DictionaryStore').GetConstructor([type[]]@([string],[bool])).Invoke(@($catalog,$true))
$rows = @(Get-Content -Encoding utf8 $Cases | ForEach-Object {ConvertFrom-Json -InputObject $_})
$timer = [Diagnostics.Stopwatch]::new()
$writer = [IO.StreamWriter]::new($Out,$false,[Text.UTF8Encoding]::new($false))
try {
    foreach ($r in $rows) {
        $filter = if ($r.filter) {$r.filter} else {[System.Management.Automation.Language.NullString]::Value}
        $timer.Restart()
        $hits = $store.Search([string]$r.query,$filter,[Threading.CancellationToken]::None)
        $timer.Stop()
        $actual = @($hits | ForEach-Object {
            [ordered]@{dict=$_.Entry.DictionaryId; id=$_.Entry.EntryId; head=$_.Entry.Headword; method=$_.Method; term=$_.Term; display=$_.Display}
        })
        $writer.WriteLine((ConvertTo-Json -Compress -Depth 5 -InputObject ([ordered]@{id=$r.id;query=$r.query;actual=$actual;ms=[math]::Round($timer.Elapsed.TotalMilliseconds,4)})))
    }
} finally { $writer.Dispose(); $store.Dispose() }
