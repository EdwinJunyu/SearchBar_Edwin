"""python audit.py baseline|final [path-to-build]; seed 20261122. Uses only the SQLite snapshot, stdlib and local .NET/pwsh."""
import collections, hashlib, html, json, os, random, re, shutil, sqlite3, subprocess, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
DB = HERE.parent / "catalog.db"
dotnet_root = os.environ.get("DOTNET_ROOT")
dotnet_candidates = [
    Path(dotnet_root) / "dotnet.exe" if dotnet_root else None,
    Path(exe) if (exe := shutil.which("dotnet")) else None,
    ROOT / ".tools/dotnet/dotnet.exe",
    Path("D:/D_Main/EdwinSoftware/E_Search/.tools/dotnet/dotnet.exe"),
]
DOTNET = next((exe for exe in dotnet_candidates if exe is not None and exe.is_file()), None)
if DOTNET is None:
    raise RuntimeError("Set DOTNET_ROOT or add dotnet.exe to PATH.")
PWSH = Path(shutil.which("pwsh")).resolve().parent
SEED = 20261122
HOLDOUT_SEED = 11222027

def dump(p, rows):
    p.write_text("".join(json.dumps(row,ensure_ascii=False,separators=(",",":"))+"\n" for row in rows),"utf-8")
def load(p):
    return [json.loads(x) for x in p.read_text("utf-8-sig").splitlines()]
def plain(text):
    return " ".join(html.unescape(re.sub(r"<[^>]+>", "",text)).split())
def generate(holdout=False):
    rng = random.Random(HOLDOUT_SEED if holdout else SEED)
    db = sqlite3.connect(DB.as_uri()+"?mode=ro&immutable=1", uri=True)
    entries = db.execute("select ordinal,head,gloss,raw from entries where dict='oxford' and link is null order by ordinal").fetchall()
    lex = {h.lower() for _,h,g,r in entries}
    terms = {k for k, in db.execute("select distinct term from terms where dict='oxford' and kind=0")}
    cases = []
    def add(suite,query,expected,source,only="oxford"):
        cases.append(dict(suite=suite,query=query,expected=expected,source=source,filter=only))
    # Linguistically specified surface→lemma pairs, independent of application output.
    families = """
    ask asks asked asking; walk walks walked walking; look looks looked looking; call calls called calling; help helps helped helping;
    work works worked working; start starts started starting; play plays played playing; stay stays stayed staying; enjoy enjoys enjoyed enjoying;
    watch watches watched watching; match matches matched matching; wish wishes wished wishing; fix fixes fixed fixing; mix mixes mixed mixing;
    use uses used using; close closes closed closing; move moves moved moving; love loves loved loving; smile smiles smiled smiling;
    dance dances danced dancing; hope hopes hoped hoping; change changes changed changing; serve serves served serving; live lives lived living;
    hurry hurries hurried hurrying; carry carries carried carrying; study studies studied studying; copy copies copied copying;
    stop stops stopped stopping; plan plans planned planning; drop drops dropped dropping; rub rubs rubbed rubbing;
    travel travels travelled travelling; control controls controlled controlling; occur occurs occurred occurring; admit admits admitted admitting;
    allow allows allowed allowing; open opens opened opening; visit visits visited visiting; listen listens listened listening;
    eat ate eaten; speak spoke spoken; write wrote written; ride rode ridden; sing sang sung; drink drank drunk; go went gone;
    take took taken; see saw seen; give gave given; drive drove driven; choose chose chosen; know knew known; grow grew grown;
    begin began begun; break broke broken; fly flew flown; throw threw thrown; wear wore worn; buy bought; teach taught;
    feel felt; leave left; keep kept; lose lost; meet met; find found; build built; bring brought; catch caught;
    child children; foot feet; tooth teeth; goose geese; mouse mice; woman women; man men; person people;
    series series; leaf leaves; knife knives; wife wives; hero heroes; potato potatoes; bus buses; city cities; day days
    """
    pairs = [(form,parts[0]) for line in families.replace("\n"," ").split(";") if (parts:=line.strip().split())
             for form in parts[1:] if parts[0] in lex and form!=parts[0]]
    for form,lemma in rng.sample(pairs,min(len(pairs),145)):
        add("en_morphology", form,{"lemma":lemma},"fixed English paradigm, indexed lemma verified")
    # Typos are one edit away from a pre-existing lexical entry. Exclude real dictionary terms and equal-distance competitors.
    targets=sorted(w for w in lex if re.fullmatch("[a-z]{7,13}",w) and not w.endswith(("s","ed","ing")))
    rng.shuffle(targets)
    letters="abcdefghijklmnopqrstuvwxyz"
    total=0
    for target in targets:
        kind=total%4
        i=rng.randrange(1,len(target)-2)
        other=rng.choice([x for x in letters if x!=target[i]])
        q=(target[:i]+target[i+1]+target[i]+target[i+2:] if kind==0 else
           target[:i]+target[i+1:] if kind==1 else target[:i]+other+target[i:] if kind==2 else target[:i]+other+target[i+1:])
        if q in terms or q==target: continue
        edits={q[:j]+q[j+1:] for j in range(len(q))}
        edits.update(q[:j]+q[j+1]+q[j]+q[j+2:] for j in range(len(q)-1))
        for j in range(len(q)+1):
            for ch in letters:
                edits.add(q[:j]+ch+q[j:])
                if j<len(q): edits.add(q[:j]+ch+q[j+1:])
        if edits & lex != {target}: continue
        add("en_spelling",q,{"spelling":target},f"Oxford single headword, unique one-edit neighbor; edit {kind}")
        total+=1
        if total==130: break
    if holdout:
        # Independently ambiguous typos: several genuine words are equally close. Do not assume their relative order.
        # Compute the admissible set for the oracle by independently comparing the typo to each short lexical entry.
        def one_edit(a,b):
            if len(a)==len(b):
                dif=[i for i in range(len(a)) if a[i]!=b[i]]
                return len(dif)==1 or (len(dif)==2 and dif[1]==dif[0]+1 and a[dif[0]]==b[dif[1]] and a[dif[1]]==b[dif[0]])
            if len(a)>len(b): a,b=b,a
            return len(a)+1==len(b) and any(b[:j]+b[j+1:]==a for j in range(len(b)))
        short=sorted(w for w in lex if re.fullmatch("[a-z]{3,5}",w))
        short_terms=set(short)
        ambiguous=0
        for w in rng.sample(short,len(short)):
            i=rng.randrange(len(w)); q=w[:i]+rng.choice(letters)+w[i+1:]
            if q in terms or q.endswith(("s","ed","ing")) or q in short_terms: continue
            near=[v for v in sorted(lex) if abs(len(v)-len(q))<=1 and v.isascii() and v.isalpha() and one_edit(q,v)]
            if len(near)<2: continue
            add("en_spelling_ambiguous",q,{"neighbors":near},"independent lexical edit-distance set, no frequency/rank assumption")
            ambiguous+=1
            if ambiguous==24:break
    # Sample exact compound headwords. Quotes delimit the span, so sentence context cannot create a longer competing phrase.
    compounds=[(i,h,g) for i,h,g,_ in entries if re.fullmatch("[a-z]+(?: [a-z]+){1,3}",h)
               and re.search("[\u4e00-\u9fff]",g) and len(h)<=38 and not re.search(r"\b(sb|sth)\b",h)]
    comp=rng.sample(compounds,82)
    for j,(ordinal,head,gloss) in enumerate(comp):
        query=f'I looked up “{head}” today.'
        add("en_compound",query,{"entry":ordinal,"surface":head},"exact Oxford headword",None if j%3==0 else "oxford")
    # Oxford explicit cross-references. Oracle reads a single direct relation and independently verifies a defined Chinese target.
    # Restrict to source entries whose original stored preview is just the source name (no separate source sense).
    trans={h.lower() for _,h,g,_ in entries if re.search("[\u4e00-\u9fff]",g)}
    refs=[]
    anchor=re.compile(r'<a\s+href\s*=\s*["\']entry://([^"\']+)["\'][^>]*>',re.I)
    relation=re.compile(r'(?:\b(pt|pp|pl)\.?(?:\s*(?:,|and|/)\s*(pt|pp)\.?)?\s+of|(?<![\w=])=|\bsee)\s*$',re.I)
    for ordinal,h,g,raw in entries:
        if g.strip().casefold()!=h.casefold() or not re.fullmatch("[a-z]+",h): continue
        segment=re.split(r"【(?:PHR V|IDIOMS|HELP|ORIGIN)】|♦",raw,maxsplit=1)[0]
        targets=set()
        for mark in anchor.finditer(segment):
            # HTML tags delimit text runs; preserve a word boundary for abbreviations glued to the headword by inline tags.
            prev=html.unescape(re.sub("<[^>]*>"," ",segment[max(0,mark.start()-250):mark.start()]))
            m=relation.search(prev)
            if m: targets.add((mark[1].lower(),m[1].lower() if m[1] else "see"))
        if len(targets)!=1: continue
        dest,rel=next(iter(targets))
        if not re.fullmatch("[a-z]+(?:[ '-][a-z]+)*",dest) or dest==h or dest not in trans: continue
        refs.append((ordinal,h,dest,rel))
    for rel in ["pt","pp","pl","see"]:
        group=[r for r in refs if r[3]==rel]
        for ordinal,h,dest,_ in rng.sample(group,min(len(group),14)):
            add("en_reference",h,{"reference":dest,"id":ordinal},f"source body links directly to defined target ({rel})")
    # PHR V section heading plus translation before the next heading. Sample only strict actual bold, blue bullet headings.
    headmark=re.compile(r'<span\s+style="color:blue;font-weight:bold">\s*<font color=red>◘</font>(.*?)</span>',re.I|re.S)
    orange=re.compile(r'<font color=#FF5000>(.*?)</font>',re.I|re.S)
    pool={"en_phrasal":[],"en_separable":[]}
    particles={"up","down","off","on","out","in","away","back","through","around","over","apart","along","round","aside"}
    for ordinal,h,g,raw in entries:
        if "【PHR V】" not in raw or not re.fullmatch("[a-z]+",h): continue
        section=raw.split("【PHR V】",1)[1]
        section=re.split(r'【IDIOMS】|<font color=darkred font=\+1><b><i>',section,maxsplit=1,flags=re.I)[0]
        marks=list(headmark.finditer(section))
        for idx,m in enumerate(marks):
            title=plain(m[1]).replace("7","").replace("'","").strip().lstrip("| ").strip()
            body=section[m.end():marks[idx+1].start() if idx+1<len(marks) else len(section)]
            found=orange.search(re.split("color:#04F",body,maxsplit=1,flags=re.I)[0])
            if not found: continue
            gloss=plain(found[1]).lstrip("• ").strip()
            if not re.search("[\u4e00-\u9fff]",gloss): continue
            mt=re.fullmatch(re.escape(h)+r" (sb|sth)(?: / (sb|sth))?[∽↔]([a-z]+)",title)
            if mt and mt[3] in particles:
                obj="him" if mt[1]=="sb" else "it"
                q=f"{h} {obj} {mt[3]}"
                if q not in terms: pool["en_separable"].append((ordinal,q,gloss))
            elif mm:=re.fullmatch(re.escape(h)+r" ([a-z]+)(?: (?:sb|sth)(?: / (?:sb|sth))?)?",title):
                q=h+" "+mm[1]
                if mm[1] in particles and q not in terms:
                    pool["en_phrasal"].append((ordinal,q,gloss))
    for category,items in pool.items():
        byquery=collections.defaultdict(list)
        for ordinal,q,gloss in items: byquery[q].append((ordinal,gloss))
        for q in rng.sample(sorted(byquery),35):
            # With no contextual disambiguation, accept any one actual matching heading's cited translation.
            proofs=byquery[q]
            add(category,'They said “'+q+'”.',{"entry":proofs[0][0],"surface":q,"gloss_any":sorted(set(g[:12] for _,g in proofs))},
                "independent raw heading and orange Chinese sense before next marked heading")
    for j,(_,h,_) in enumerate(comp[:25]):
        q=h.replace(" ",", ")
        add("en_negative_boundary",q,{"empty":True},"punctuation between every token of original indexed compound")
    for j in range(15):
        q="qzx"+''.join(rng.choice("zqxjv") for _ in range(9))
        assert q not in terms
        add("en_negative_noise",q,{"empty":True},"seeded nonword with no plausible lexical target")
    if holdout:
        old={(c["suite"],c["query"]) for c in load(HERE/"cases.jsonl")}
        cases=[c for c in cases if (c["suite"],c["query"]) not in old]
    rng.shuffle(cases)
    for i,c in enumerate(cases): c["id"]=i
    dump(HERE/("holdout-cases.jsonl" if holdout else "cases.jsonl"),cases)
    return cases

def check(c, hits):
    e=c["expected"]
    if "primary_sense" in e:
        return bool(hits and hits[0]["head"].lower()==c["query"] and e["primary_sense"] in hits[0]["display"]
                    and e["reject_note"] not in hits[0]["display"]
                    and ("reference" not in e or "（"+e["reference"]+" 的过去分词）" in hits[0]["display"]))
    if "empty" in e: return not hits
    if "lemma" in e:
        word=e["lemma"]
        return any((h["head"].lower()==word and h["method"] in ["headword","deinflection"]) or
                   ("→ "+word+" ·" in h["display"] or "（"+word+" 的" in h["display"]) for h in hits)
    if "neighbors" in e:
        return 0<len(hits)<=3 and len({h["head"].lower() for h in hits})==len(hits) and all(
            h["method"]=="spelling" and h["head"].lower() in e["neighbors"] for h in hits)
    if "spelling" in e:
        return len(hits)<=3 and any(h["method"]=="spelling" and h["head"].lower()==e["spelling"] for h in hits)
    if "reference" in e:
        return any(h["id"]==e["id"] and h["method"]=="headword" and
                   ("→ "+e["reference"]+" ·" in h["display"] or "（"+e["reference"]+" 的" in h["display"])
                   and re.search("[\u4e00-\u9fff]",h["display"].split("·")[-1]) for h in hits)
    return any(h["dict"]=="oxford" and h["id"]==e["entry"] and h["method"]=="phrase" and h["term"]==e["surface"]
               and ("gloss_any" not in e or any(g in h["display"] for g in e["gloss_any"])) for h in hits)

if __name__=="__main__":
    stage=sys.argv[1]
    holdout=stage.startswith("holdout-")
    casefile=HERE/("holdout-cases.jsonl" if holdout else "cases.jsonl")
    if stage.startswith("gloss-"):
        # Four explicitly reviewed source bodies. These targeted checks remain separate from both seeded cohorts.
        casefile=HERE/"gloss-cases.jsonl"
        cases=[]
        for i,(word,sense,note,source) in enumerate([
            ("show","表明；证明","有时或作","Oxford show #33780, verb sense 1: MAKE CLEAR; preceding grammar table describes a rare variant."),
            ("shown","表明；证明","有时或作","Oxford shown #33795 links to show as pp; use show verb sense 1."),
            ("person","人；个人","正式用语常作","Oxford person #27409, noun sense 1: a human as an individual; formal-usage note qualifies plural persons."),
            ("formula","公式；方程式；计算式","科技用语常作","Oxford formula #14534, noun sense 1: mathematical rule; scientific-usage note qualifies plural formulae.")
        ]):
            expect={"primary_sense":sense,"reject_note":note}
            if word=="shown": expect["reference"]="show"
            cases.append(dict(suite="en_note_vs_sense",query=word,expected=expect,source=source,filter="oxford",id=i))
        dump(casefile,cases)
    else:
        cases=generate(holdout) if stage.endswith("baseline") or not casefile.exists() else load(casefile)
    b=Path(sys.argv[2]).resolve() if len(sys.argv)>2 else HERE/"bin-baseline" if stage.endswith("baseline") else ROOT/"bin"/"Release"/"net10.0"
    command=[str(DOTNET),"exec","--runtimeconfig",str(b/"E_Search.runtimeconfig.json"),"--depsfile",str(PWSH/"pwsh.deps.json"),
             str(PWSH/"pwsh.dll"),"-NoProfile","-File",str(HERE/"query.ps1"),str(b),str(HERE/(stage+"-actual.jsonl")),str(casefile)]
    subprocess.run(command,check=True)
    rows=[]
    for c,r in zip(cases,load(HERE/(stage+"-actual.jsonl")),strict=True):
        assert r["id"]==c["id"]
        rows.append({**c,"actual":r["actual"],"pass":bool(check(c,r["actual"])),"ms":r["ms"]})
    dump(HERE/(stage+".jsonl"),rows)
    print("cases",len(rows),"pass",sum(r["pass"] for r in rows),"dll",hashlib.sha256((b/"E_Search.dll").read_bytes()).hexdigest())
    print("failed",dict(collections.Counter(r["suite"] for r in rows if not r["pass"])))

