"""Independent source check for the printed Chinese text of the first Shogakukan sense."""
import collections, html.parser, json, random, re, sqlite3, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parent
SEED=20261123
class Lines(html.parser.HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.rows=[""]
    def handle_starttag(self, name, attrs):
        if name in ("br","p","hr"): self.rows.append("")
    def handle_data(self,data): self.rows[-1]+=data.strip()

def glyphs(s):
    # Domain, Japanese guideword, and grammatical labels may legitimately appear in the preview.
    s=re.sub(r"〔[^〕]*〕|［[^］]*］|《[^》]*》|〈[^〉]*〉|【[^】]*】","",s)
    return "".join(re.findall(r"[㐀-䶿一-鿿]",s))

def first_sense(raw,reading):
    parser=Lines()
    parser.feed(raw)
    rows=[v.strip() for v in parser.rows if v.strip()]
    if not rows: return None
    if not re.fullmatch(r"[ぁ-ゖァ-ヺー・－―（）()‐\-]+",rows[0]): return None
    rows=rows[1:]
    if rows and rows[0].startswith("【") and rows[0].endswith("】"): rows=rows[1:]
    special=rows[:2] in (["例：","【１】"],["例：","【1】"],["例:","【1】"],["例:","【１】"])
    if special: rows=rows[2:]
    for line in rows:
        if line.startswith(("例：","例:")):return None
        plain=glyphs(line)
        if not plain: continue
        # Do not skip a plausible translation looking for an easier later one. Require pinyin
        # on that first non-heading row as an independent witness that it is the Chinese sense.
        if not re.search(r"[āáǎàēéěèīíǐìōóǒòūúǔùǖǘǚǜ]",line):return None
        examples=[]
        for ix,row in enumerate(rows):
            if row.startswith(("例：","例:")):
                examples=[glyphs(x) for x in rows[ix+1:ix+3] if len(glyphs(x))>=3 and glyphs(x) not in plain]
                break
        category="group" if special else "labelled" if re.search(r"[(（]1[)）]|〔|［",raw[:500]) else "example" if examples else "plain"
        return dict(glyphs=plain,source_line=line,example_fragments=examples,reading=reading), category

def write_manifest():
    db=sqlite3.connect((ROOT.parent/"catalog.db").as_uri()+"?immutable=1",uri=True)
    rows=[json.loads(line) for line in (ROOT.parent/"primary/sample.jsonl").read_text("utf8").splitlines()]
    rng=random.Random(SEED); groups=collections.defaultdict(list); excluded=0
    for row in rows:
        if row["book"]!="shogakukan":continue
        h,r,raw=db.execute("select head,reading,raw from entries where dict='shogakukan' and ordinal=?",(row["ordinal"],)).fetchone()
        gold=first_sense(raw,r)
        if not gold: excluded+=1;continue
        ex,cat=gold
        groups[row["partition"],cat].append(dict(suite="shogakukan-"+cat,query=row["query"],expected=ex,ordinal=row["ordinal"],partition=row["partition"]))
    cases=[]
    for key,items in sorted(groups.items()):
        rng.shuffle(items)
        cases+=items[:32] # stratified random; all eligible cases kept when a stratum has <32
    out=ROOT/"cases.json"; payload=json.dumps(cases,ensure_ascii=False,indent=1)+"\n"
    if out.exists() and out.read_text("utf8")!=payload:raise RuntimeError("frozen manifest differs")
    if not out.exists():out.write_text(payload,"utf8")
    print("excluded before sampling",excluded,"eligible pools",{str(k):len(v) for k,v in groups.items()},"n",len(cases))

def score(stage):
    out=ROOT/(stage+".jsonl")
    if stage=="baseline" and out.exists():raise RuntimeError("baseline already exists")
    continuation=stage.startswith("continuation-")
    cases=json.loads((ROOT/(stage.rsplit("-",1)[0]+"-cases.json" if continuation else "cases.json")).read_text("utf8"))
    raw=[json.loads(row) for row in (ROOT/(stage+"-observed.jsonl")).read_text("utf8").splitlines()]
    assert len(cases)==len(raw)
    rows=[]
    for case,actual in zip(cases,raw):
        assert case["ordinal"]==actual["ordinal"]
        exp=case["expected"]; value=actual["actual"] or ""
        content=glyphs(value)
        # The displayed ideographs must spell the source sense in order. If the app explicitly
        # truncates a long definition, at least its first two source ideographs must be visible.
        same=content.startswith(exp["required"]) if continuation else (content==exp["glyphs"] or (value.endswith("…") and len(content)>=2 and exp["glyphs"].startswith(content)))
        example_leak=any(x in content for x in exp.get("example_fragments",[]))
        reading_leak=bool(exp["reading"] and value.startswith(exp["reading"]) and not exp["source_line"].startswith(exp["reading"]))
        rows.append(dict(**case,actual=value,ms=actual["ms"],**{"pass":bool(same and not example_leak and not reading_leak)},
                         found=actual["found"],example_leak=example_leak,reading_leak=reading_leak))
    out.write_text("".join(json.dumps(c,ensure_ascii=False)+"\n" for c in rows),"utf8")
    for k in sorted(set(c["suite"] for c in rows)):
        x=[c for c in rows if c["suite"]==k]; print(k,sum(c["pass"] for c in x),len(x))

if __name__=="__main__":
    write_manifest() if len(sys.argv)==1 else score(sys.argv[1])
