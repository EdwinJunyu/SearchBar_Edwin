param([ValidateSet('baseline','final')][string]$Stage, [switch]$Continuation,[switch]$Strict)
$ErrorActionPreference='Stop'
$bin=if ($Stage -eq 'baseline') { Join-Path $PSScriptRoot '../japanese/baseline-bin' } else { Join-Path $PSScriptRoot '../../../bin/Release/net10.0' }
foreach ($lib in 'SQLitePCLRaw.core','SQLitePCLRaw.provider.winsqlite3','Microsoft.Data.Sqlite','E_Search') {
    $asm=[Reflection.Assembly]::LoadFrom((Resolve-Path (Join-Path $bin "$lib.dll")).Path)
}
[SQLitePCL.raw]::SetProvider([SQLitePCL.SQLite3Provider_winsqlite3]::new())
$dbpath=(Resolve-Path (Join-Path $PSScriptRoot '../catalog.db')).Path.Replace('\','/')
$store=$asm.GetType('DictionaryStore').GetConstructor([type[]]@([string],[bool])).Invoke([object[]]@("file:$($dbpath)?immutable=1",$true))
$prefix=if ($Strict) { 'continuation-strict-' } elseif ($Continuation) { 'continuation-' } else { '' }
$cases=Get-Content -Raw -Encoding utf8 (Join-Path $PSScriptRoot ($prefix+'cases.json')) | ConvertFrom-Json
$path=Join-Path $PSScriptRoot "$prefix$Stage-observed.jsonl"
if ($Stage -eq 'baseline' -and (Test-Path $path)) { throw 'Baseline already preserved.' }
$writer=[IO.StreamWriter]::new($path,$false,[Text.UTF8Encoding]::new($false))
try {
    foreach($c in $cases) {
        $sw=[Diagnostics.Stopwatch]::StartNew()
        $rows=$store.Search([string]$c.query,'shogakukan',[Threading.CancellationToken]::None)
        $sw.Stop()
        $hit=$rows|Where-Object { $_.Entry.EntryId -eq $c.ordinal }|Select-Object -First 1
        $writer.WriteLine(([ordered]@{ordinal=$c.ordinal;actual=$hit.Entry.Gloss;ms=[math]::Round($sw.Elapsed.TotalMilliseconds,3);found=[bool]$hit} | ConvertTo-Json -Compress))
    }
} finally {$writer.Dispose();$store.Dispose()}
python (Join-Path $PSScriptRoot evaluate.py) "$prefix$Stage"
if($LASTEXITCODE -ne 0){ exit $LASTEXITCODE }
