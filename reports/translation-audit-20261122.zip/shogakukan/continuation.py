"""Frozen challenge set for an initial translation continued after a Chinese alternative in brackets."""
import collections, json, random, re, sqlite3
from pathlib import Path
from evaluate import ROOT, Lines, glyphs

db=sqlite3.connect((ROOT.parent/"catalog.db").as_uri()+"?immutable=1",uri=True)
rows=[]; seen=set()
for h,reading,n,raw in db.execute("select head,reading,ordinal,raw from entries where dict='shogakukan' and link is null order by ordinal"):
    if h in seen or "〕</font><br>" not in raw[:950]: continue
    # Use document-order blocks, identify first translated material before the next sense or examples.
    p=Lines(); p.feed(raw[:4096])
    lines=[v for v in p.rows if v.strip()]
    if not lines:continue
    start=2 if len(lines)>1 and lines[1].startswith("【") else 1
    for i in range(start,min(start+4,len(lines)-1)):
        left=lines[i]
        if left.startswith(("例：","例:","(2)")): break
        if not left.endswith("〕"):
            if glyphs(left):break
            continue
        m=re.match(r"^([一-鿿]+)([a-zA-ZÀ-žǍ-ǜ]+(?:\s+[a-zA-ZÀ-žǍ-ǜ]+)*)",lines[i+1])
        if not m or not re.search(r"[āáǎàēéěèīíǐìōóǒòūúǔùǖǘǚǜ]",m[2]):break
        prefix=glyphs(left)
        if "--strict" in __import__("sys").argv and (not prefix or re.search(r"[ぁ-ヺ]",left)): break
        fragment=prefix+m[1]
        if len(fragment)<2:break
        rows.append(dict(suite="shogakukan-continuation",query=h,ordinal=n,
                    expected=dict(required=fragment,source_line=left,following=lines[i+1],reading=reading)))
        seen.add(h);break
rng=random.Random(20261124); cases=rng.sample(rows,min(96,len(rows)))
out=ROOT/("continuation-strict-cases.json" if "--strict" in __import__("sys").argv else "continuation-cases.json");payload=json.dumps(cases,ensure_ascii=False,indent=1)+"\n"
if out.exists() and out.read_text("utf-8")!=payload:raise RuntimeError("frozen manifest differs")
if not out.exists():out.write_text(payload,"utf-8")
print("eligible distinct heads:",len(rows),"sample:",len(cases))
